<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
 		parent::__construct();
		$this->load->library('form_validation');
		$this->load->database();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('Register_model');
	}	
	public function input(){
		$this->form_validation->set_rules('username', 'Username', 'required|max_length[100]');			
		$this->form_validation->set_rules('name', 'Name', 'required|max_length[100]');			
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|max_length[100]');			
		$this->form_validation->set_rules('phone_number', 'Phone Number', 'required|is_numeric|max_length[100]');					
		$this->form_validation->set_rules('address', 'Address', 'required|max_length[1000]');			
		$this->form_validation->set_rules('password', 'Password', 'required|max_length[100]');			
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|max_length[100]');
			
		$this->form_validation->set_error_delimiters('<br /><span class="error">', '</span>');

		$this->load->model('User_model','user');
		if(!$this->user->checkUserValidity($_POST['username']))
		{
			$data['content']='FrontEnd/register';
			$data['title']='Register';
			
			//data for body
			$this->load->model('Product_model','product');
			$data['error'] = "Username not available";
			
			//data for header
			$this->load->model('Category_model','category');
			$data['category'] = $this->category->loadCategories();
			
			$this->load->view('FrontEnd/master',$data);
			return;
		}
	
		if ($this->form_validation->run() == FALSE) // validation hasn't been passed
		{
			$data['content']='FrontEnd/register';
			$data['title']='Register';
			$this->load->model('Category_model','category');
			$data['category'] = $this->category->loadCategories();
			
			$this->load->view('FrontEnd/master',$data);
		}
		else // passed validation proceed to post success logic
		{
		 	// build array for the model
		 	$UserID = "U".substr(set_value('name'),0,2).date('Ymdhis').substr(microtime(), 2,3);
			$form_data = array(
							'userid' => $UserID,
					       	'username' => set_value('username'),
					       	'name' => set_value('name'),
					       	'email' => set_value('email'),
					       	'phone_number' => set_value('phone_number'),
					       	'date_of_birth' => (!(set_value('date_of_birth'))) ? date() : set_value('date_of_birth'),
					       	'address' => set_value('address'),
					       	'password' => set_value('password'),
					       	'confirm_password' => set_value('confirm_password')
						);
					
			// run insert model to write data to db

			if ($this->Register_model->SaveForm($form_data) == TRUE) // the information has therefore been successfully saved in the db
			{
				//modified by FS 3 Des
				//langsung set udah login, pindah ke home aja
				redirect('Home');
			}
		}
	}
	public function index()
	{
		$data['content']='FrontEnd/register';
		$data['title']='Register';
		
		//data for body
		$this->load->model('Product_model','product');
		
		//data for header
		$this->load->model('Category_model','category');
		//modified by FS 3 Des
		$data['category'] = $this->category->loadCategories();
		
		$this->load->view('FrontEnd/master',$data);
	}
}

