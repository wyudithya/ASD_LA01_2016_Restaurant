<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EditProfile extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
 		parent::__construct();
		$this->load->library('form_validation');
		$this->load->database();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('EditProfile_model');
	}	
	public function input(){
		$this->form_validation->set_rules('username', 'Username', 'required|max_length[100]');			
		$this->form_validation->set_rules('name', 'Name', 'required|max_length[100]');			
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|max_length[100]');			
		$this->form_validation->set_rules('phone_number', 'Phone Number', 'required|is_numeric|max_length[100]');					
		$this->form_validation->set_rules('address', 'Address', 'required|max_length[1000]');			
			
		$this->form_validation->set_error_delimiters('<br /><span class="error">', '</span>');
	
		if ($this->form_validation->run() == FALSE) // validation hasn't been passed
		{	
			$data['value']="";
			$data['content']='FrontEnd/edit_profile';
			$data['title']='Profile';
			$this->load->model('Category_model','category');
			$data['category'] = $this->category->loadCategories();
			
			$this->load->view('FrontEnd/master',$data);
		}
		else // passed validation proceed to post success logic
		{
		 	// build array for the model
			$form_data = array(
					       	'username' => set_value('username'),
					       	'name' => set_value('name'),
					       	'email' => set_value('email'),
					       	'phone_number' => set_value('phone_number'),
					       	'date_of_birth' => (empty(set_value('date_of_birth'))) ? date() : set_value('date_of_birth'),
					       	'address' => set_value('address')
						);
					
			// run insert model to write data to db

			if ($this->EditProfile_model->SaveForm($form_data) == TRUE) // the information has therefore been successfully saved in the db
			{
				//modified by FS 3 Des
				//langsung set udah login, pindah ke home aja
				redirect('Home');
			}
		}
	}
	public function index()
	{	
		$id = $this->session->userdata('userID');
		$query = $this->EditProfile_model->GetData($id);
		$data['value'] = array(
							'name' => $query->row(0)->Name,
							'username' => $query->row(0)->Username,
					       	'email' => $query->row(0)->Email,
					       	'phone_number' => $query->row(0)->PhoneNumber,
					       	'date_of_birth' => $query->row(0)->DOB,
					       	'address' => $query->row(0)->Address
						);
		if($this->session->userdata('username')){
			$data['content']='FrontEnd/edit_profile';
			$data['title']='Profile';
			
			//data for header
			$this->load->model('Category_model','category');
			//modified by FS 3 Des
			$data['category'] = $this->category->loadCategories();
			
			$this->load->view('FrontEnd/master',$data);
		}else{
			redirect('Login');
		}
	}
}

