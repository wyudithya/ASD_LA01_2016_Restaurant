<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('Category_model','category');
		$data = $this->admin->initializeTemplate();
		//$data["categories"] = $this->category->getCategory();
		$this->load->view('BackEnd/BackEndCategory',$data);
	}

	public function delete($id)
	{
		$this->checkLogin();
		$this->load->model('Category_model','category');
		$this->category->deleteCategory($id);
		redirect(base_url().'BackEnd/Category');
	}

	public function edit($id)
	{
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('Category_model','category');
		$data = $this->admin->initializeTemplate();
		$data["currentData"] = $this->category->getCategoryName($id);
		$data["currentID"] = $id;
		$data["parentCategory"] = $this->category->getParentCategory();
		$this->load->view('BackEnd/BackEndCategoryEdit',$data);
	}

	public function update($id)
	{
		$this->checkLogin();
		$this->load->model('Category_model','category');
		$this->category->updateCategory($this->input->post()["txt_name"],$this->input->post()["chkSubCategory"],$this->input->post()["parentCategory"],$id);
		redirect(base_url().'BackEnd/Category');
	}

	public function addNew()
	{
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('Category_model','category');
		$data = $this->admin->initializeTemplate();
		$data["parentCategory"] = $this->category->getParentCategory();
		$this->load->view('BackEnd/BackEndCategoryEdit',$data);
	}

	public function addCategory()
	{
		$this->checkLogin();
		$this->load->model('Category_model','category');
		$this->category->insertCategory($this->input->post()["txt_name"],$this->input->post()["chkSubCategory"],$this->input->post()["parentCategory"]);
		redirect(base_url().'BackEnd/Category');
	}

	private function checkLogin()
	{
		if($this->session->userdata('username')!=null&&$this->session->userdata('username')!="")
		{
			if($this->session->userdata('userType')=="Customer")
			{
				redirect(base_url()."Home");
			}
		}
		else
		{
			redirect(base_url()."BackEnd/Login");
		}
	}
	//add, edit, delete
	//view
}
