<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function index()
	{
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('User_model','user');
		$data = $this->admin->initializeTemplate();
		$data['user'] = $this->user->getAllUser(); 
		$this->load->view('BackEnd/BackEndUser',$data);
	}


	public function detail($id){
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('User_model','user');
		$data = $this->admin->initializeTemplate();
		$data['userdetail'] = $this->user->getUserByID($id); 
		$this->load->view('BackEnd/BackEndUserDetail',$data);
	}

	public function deleteUser($id)
	{
		$this->checkLogin();
		$this->load->model('User_model','user');
		$data = $this->user->deleteUserByID($id);
	}


	public function updateUser($id)
	{

		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('User_model','user');
		$data = $this->admin->initializeTemplate();			
		$data['userdetail'] = $this->user->getUserByID($id);
		
		$data_insert = $this->input->post();
		if(!empty($data_insert)){
			$this->user->UpdateUserByID($id,$data_insert);
			
		}
		$this->load->view('BackEnd/BackEndUserDetailUpdate',$data);
	}


	private function checkLogin()
	{
		if($this->session->userdata('username')!=null&&$this->session->userdata('username')!="")
		{
			if($this->session->userdata('userType')=="Customer")
			{
				redirect(base_url()."Home");
			}
		}
		else
		{
			redirect(base_url()."BackEnd/Login");
		}
	}
}
