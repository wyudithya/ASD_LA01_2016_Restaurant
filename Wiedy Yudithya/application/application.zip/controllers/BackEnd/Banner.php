<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banner extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('Banner_model','banner');
		$data = $this->admin->initializeTemplate();
		$data['banner'] = $this->banner->getAllBanner();
		$this->load->view('BackEnd/BackEndBanner',$data);
	}
public function editBanner($id)
	{
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('Category_model','category');
		$this->load->model('Product_model','product');

		$this->load->model('Banner_model','banner');
		$data = $this->admin->initializeTemplate();			
		$data['category'] = $this->category->getCategory();
		$data['product'] = $this->product->getAllProduct();	

		$data['current'] = $this->banner->getBannerByID($id);
 		


		$data_insert = $this->input->post();
		if(!empty($data_insert)){

			$this->banner->UpdateBannerByID($id,$data_insert);
			
		}
		$this->load->view('BackEnd/BackEndBannerEdit',$data);
	}
	public function showProduct(){

		$data_insert = $this->input->post();
		$this->checkLogin();

		$this->load->model('Admin_model','admin');
		$this->load->model('Product_model','product');
		$data = $this->admin->initializeTemplate();
		if($data_insert['CategoryID'] != 0 )
			$data['product'] = $this->product->getProductbyCategory($data_insert['CategoryID']);
		else
			$data['product'] = $this->product->getAllProduct();
		echo json_encode($data['product']);

	}
public function addBanner()
	{
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('Category_model','category');
		$this->load->model('Product_model','product');

		$this->load->model('Banner_model','banner');
		$data = $this->admin->initializeTemplate();			
		$data['category'] = $this->category->getCategory();
		$data['product'] = $this->product->getAllProduct();	
			
		$data_insert = $this->input->post();

		if(!empty($data_insert)){
			$this->banner->Addbanner($data_insert);
		}
		$this->load->view('BackEnd/BackEndBannerAdd',$data);
	}

	public function deleteBannerByID($id){
		$this->checkLogin();
		$this->load->model('Banner_model','banner');
		$result = $this->banner->deleteBannerByID($id);
	}

	private function checkLogin()
	{
		if($this->session->userdata('username')!=null&&$this->session->userdata('username')!="")
		{
			if($this->session->userdata('userType')=="Customer")
			{
				redirect(base_url()."Home");
			}
		}
		else
		{
			redirect(base_url()."BackEnd/Login");
		}
	}
}
