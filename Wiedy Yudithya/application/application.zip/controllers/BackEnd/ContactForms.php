<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ContactForms extends CI_Controller {

	public function index()
	{
		$this->checkLogin();
		$data = [];
		$this->load->model('Admin_model','admin');
		$this->load->model('Contactform_model','contact');
		$data = $this->admin->initializeTemplate();	
		$data["contact"] = $this->contact->getAllContact();
		$this->load->view('BackEnd/BackEndContactForms',$data);
	}

	public function detail($contactID)
	{
		$this->checkLogin();
		$data = [];
		$this->load->model('Admin_model','admin');
		$this->load->model('Contactform_model','contact');
		$this->contact->removeFromNotification($contactID);
		$data = $this->admin->initializeTemplate();
		$data["contactDetail"] = $this->contact->getContactByID($contactID);
		$this->load->view('BackEnd/BackEndContactFormsDetail',$data);
	}

	public function deleteContact($contactID)
	{
		$this->checkLogin();
		$this->load->model('Contactform_model','contact');
		$result = $this->contact->deleteContactByID($contactID);
	}


	private function checkLogin()
	{
		if($this->session->userdata('username')!=null&&$this->session->userdata('username')!="")
		{
			if($this->session->userdata('userType')=="Customer")
			{
				redirect(base_url()."Home");
			}
		}
		else
		{
			redirect(base_url()."BackEnd/Login");
		}
	}
}
