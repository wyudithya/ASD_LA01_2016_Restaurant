<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->checkLogin();
		$data = [];
		$this->load->model('Admin_model','admin');
		$this->load->model('Order_model','order');
		$data = $this->admin->initializeTemplate();
		$data["orders"] = $this->order->getAllOrders();
		$this->load->view('BackEnd/BackEndOrders',$data);
	}
	public function viewOrder()
	{
		$status = $this->uri->segment(4);
		$this->checkLogin();
		$data = [];
		$this->load->model('Admin_model','admin');
		$this->load->model('Order_model','order');
		$data = $this->admin->initializeTemplate();
		$data["orders"] = $this->order->getOrderByStatus($status);
		$data["header"] = $this->order->getOrderTypeNameByID($status);
		$this->load->view('BackEnd/BackEndOrders',$data);
	}
	public function detail()
	{
		$orderID = $this->uri->segment(4);
		$this->checkLogin();
		$data = [];
		$this->load->model('Admin_model','admin');
		$this->load->model('Order_model','order');
		$data = $this->admin->initializeTemplate();
		$data["orderDetail"] = $this->order->getOrderDetailByID($orderID);
		$data["orderHeader"] = $this->order->getOrderByID($orderID);
		$data["nextStep"] = $this->order->getNextStep($data["orderHeader"]->orderStatus,$data["orderHeader"]->paymentType);
		$this->order->removeFromNotification($orderID);
		$this->load->view('BackEnd/BackEndOrderDetail',$data);
	}
	public function next()
	{
		$orderID = $this->uri->segment(4);
		$currentStep = $this->uri->segment(5);
		$nomorResi = $this->uri->segment(6);
		$deliveryDate = $this->uri->segment(7);
		$this->checkLogin();
		$data = [];
		$this->load->model('Admin_model','admin');
		$this->load->model('Order_model','order');
		$this->load->model('Email_model');
		$this->order->goToNextStep($orderID,$currentStep);
		if($nomorResi!=null&&$nomorResi!=""&&$currentStep==3)
			$this->order->insertNomorResi($orderID,$nomorResi,$deliveryDate);
		else if($currentStep==4)
			$this->order->insertReceivedDate($orderID,$nomorResi);

		//Edit by AW to check currentstep
		if($currentStep == 2 || $currentStep == 3)
			$this->Email_model->adminProcess($orderID);
		
		$data = $this->admin->initializeTemplate();
		$data["orderDetail"] = $this->order->getOrderDetailByID($orderID);
		$data["orderHeader"] = $this->order->getOrderByID($orderID);
		$data["nextStep"] = $this->order->getNextStep($data["orderHeader"]->orderStatus,$data["orderHeader"]->paymentType);
		$this->load->view('BackEnd/BackEndOrderDetail',$data);
	}
	private function checkLogin()
	{
		if($this->session->userdata('username')!=null&&$this->session->userdata('username')!="")
		{
			if($this->session->userdata('userType')=="Customer")
			{
				redirect(base_url()."Home");
			}
		}
		else
		{
			redirect(base_url()."BackEnd/Login");
		}
	}
}
