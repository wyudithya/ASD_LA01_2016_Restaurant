<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$data = $this->admin->initializeTemplate();
		$this->load->view('BackEnd/BackEndPayment',$data);
	}

	public function detail($paymentID)
	{
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('Payment_model','payment');
		$this->payment->removeFromNotification($paymentID);
		$data = $this->admin->initializeTemplate();
		$data['paymentID'] = $paymentID;
		$data["paymentDetail"] = $this->payment->getPaymentByID($paymentID);
		$this->load->view('BackEnd/BackEndPaymentDetail',$data);
	}

	public function process($paymentID)
	{
		$this->checkLogin();
		$this->load->model('Payment_model','payment');
		$this->payment->process($paymentID);
		redirect(base_url()."BackEnd/Payment");	
	}

	private function checkLogin()
	{
		if($this->session->userdata('username')!=null&&$this->session->userdata('username')!="")
		{
			if($this->session->userdata('userType')=="Customer")
			{
				redirect(base_url()."Home");
			}
		}
		else
		{
			redirect(base_url()."BackEnd/Login");
		}
	}
}