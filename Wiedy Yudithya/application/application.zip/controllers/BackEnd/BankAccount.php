<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BankAccount extends CI_Controller {

	public function index()
	{
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('Bank_model','bank');
		$data = $this->admin->initializeTemplate();
		$data["bank"] = $this->bank->getBanks();
		$this->load->view('BackEnd/BankEndBank',$data);
	}

	public function edit()
	{
		$bankID = $this->uri->segment(4);
		$this->checkLogin();
		$this->load->model('Admin_model','admin');
		$this->load->model('Bank_model','bank');
		$data = $this->admin->initializeTemplate();
		if(isset($bankID))
			$data["bank"] = $this->bank->getBankByID($bankID);
		$this->load->view('BackEnd/BackEndBankEdit',$data);
	}

	public function update()
	{
		$bankID = $this->uri->segment(4);
		$data = $this->input->post();
		$this->checkLogin();
		$this->load->model('Bank_model','bank');
		if(isset($bankID))
			$this->bank->update($data,$bankID);
		else
			$this->bank->add($data);
		redirect(base_url()."BackEnd/BankAccount");
	}

	public function delete($bankID)
	{
		$this->checkLogin();
		$this->load->model('Bank_model','bank');
		$this->bank->delete($bankID);
		redirect(base_url()."BackEnd/BankAccount");
	}

	private function checkLogin()
	{
		if($this->session->userdata('username')!=null&&$this->session->userdata('username')!="")
		{
			if($this->session->userdata('userType')=="Customer")
			{
				redirect(base_url()."Home");
			}
		}
		else
		{
			redirect(base_url()."BackEnd/Login");
		}
	}
}
