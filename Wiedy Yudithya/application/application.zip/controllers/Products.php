<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('frontEnd/403');
	}

	public function newest($page)
	{
		//created by FS 9 Des
		$this->load->model('Category_model','category');
		$title = "New Product";

		$data['content']='FrontEnd/product';
		$data['title']='Vape - '.$title;

		//data for body
		$this->load->model("Product_model","product");
		$data['header'] = $title;
		$offset = $page*16;
		$data['product'] = $this->product->getNewProducts(16,$offset);
		
		//data for header
		$data['category'] = $this->category->loadCategories();
		$this->load->view('FrontEnd/master',$data);
	}

	public function featured($page)
	{
		//created by FS 9 Des
		$this->load->model('Category_model','category');
		$title = "Featured Product";

		$data['content']='FrontEnd/product';
		$data['title']='Vape - '.$title;

		//data for body
		$this->load->model("Product_model","product");
		$data['header'] = $title;
		$offset = $page*16;
		$data['product'] = $this->product->getFeaturedProducts(16,$offset);
		
		//data for header
		$data['category'] = $this->category->loadCategories();
		$this->load->view('FrontEnd/master',$data);
	}

	public function discount($page)
	{
		//created by FS 9 Des
		$this->load->model('Category_model','category');
		$title = "Discount Product";

		$data['content']='FrontEnd/product';
		$data['title']='Vape - '.$title;

		//data for body
		$this->load->model("Product_model","product");
		$data['header'] = $title;
		$offset = $page*16;
		$data['product'] = $this->product->getDiscountedProducts(16,$offset);
		
		//data for header
		$data['category'] = $this->category->loadCategories();
		$this->load->view('FrontEnd/master',$data);
	}

	public function popular($page)
	{
		//created by FS 9 Des
		$this->load->model('Category_model','category');
		$title = "Popular Product";

		$data['content']='FrontEnd/product';
		$data['title']='Vape - '.$title;

		//data for body
		$this->load->model("Product_model","product");
		$data['header'] = $title;
		$offset = $page*16;
		$data['product'] = $this->product->getPopularProducts(16,$offset);
		
		//data for header
		$data['category'] = $this->category->loadCategories();
		$this->load->view('FrontEnd/master',$data);
	}
}
