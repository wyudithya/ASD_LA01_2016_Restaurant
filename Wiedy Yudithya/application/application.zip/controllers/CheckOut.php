<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CheckOut extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('Order_model');
		$this->load->model('Email_model');
	}
	public function index()
	{
		if($this->session->userdata('username')){
			if($this->cart->total_items()==0){
				redirect('Cart','refresh');
			}else{
				$this->load->model('User_model','user');
				$data['user'] = $this->user->getUserByID($this->session->userdata('userID'));
				$data['content']='FrontEnd/checkOut';
				$data['title']='CheckOut';
				$this->load->model('Category_model','category');
				$this->load->model('Util','util');
				$data['category'] = $this->category->loadCategories();
				$data['cities'] = $this->util->getCityList();

				$this->load->view('FrontEnd/master',$data);
			}
		}
		else{
			redirect('Login','refresh');
		}
	}
	public function placeorder(){
		
		$TrackingID = 0;
		$this->form_validation->set_rules('recipientname', 'Recipient Name', 'required|max_length[100]');						
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|max_length[100]');			
		$this->form_validation->set_rules('phone_number', 'Phone Number', 'required|is_numeric|max_length[100]');					
		$this->form_validation->set_rules('address', 'Address', 'required|max_length[1000]');
		$this->form_validation->set_rules('Notes', 'Notes', 'max_length[1000]');			
		//$this->form_validation->set_rules('city', 'city', 'required');
			
		$this->form_validation->set_error_delimiters('<br /><span class="error">', '</span>');
	
		if ($this->form_validation->run() == FALSE) // validation hasn't been passed
		{
			//die();
			$data['content']='FrontEnd/checkOut';
			$data['title']='CheckOut';	
			$this->load->model('Category_model','category');
			$data['category'] = $this->category->loadCategories();
			$this->load->model('Util','util');
			$data['cities'] = $this->util->getCityList();
			$this->load->view('FrontEnd/master',$data);
		}
		else // passed validation proceed to post success logic
		{
			if($this->cart->total()==0)
			{
				redirect(base_url());
			}
			else
			{
				$this->load->model('Category_model','category');
				$data['category'] = $this->category->loadCategories();

				$orderID = "O".substr($this->session->userdata('userID'),0,2).date('Ymdhis').substr(microtime(), 2,3);
				$this->load->model('Util');
				$TrackingID = $this->Util->generateTrackingID($orderID);
				$data = array(
								'OrderID' => $orderID,
						       	'UserID' => $this->session->userdata('userID'),
						       	'PaymentTypeID' => 2,
						       	'OrderStatusID' => 1,
						       	'TrackingID'=> $TrackingID,
						       	'Notes' => set_value('Notes'),
						       	'address' => set_value('address')."<br>".set_value('province')."<br>".set_value('city'),
						       	'Email' => set_value('email'),
						       	'PhoneNumber' => set_value('phone_number'),
						       	'RecipientName' => set_value('recipientname'),
						       	'Total'=>$this->cart->total(),
						       	'ShippingCost'=>$_POST['ongkosKirim'],
						       	'NomorResi'=> '',
						       	'Service'=> "JNE - ".set_value('service')
				);

				$item=$this->cart->contents();
				// $grandTotal = 0;
				// foreach($item as $itemorder){
				// 	print_r($itemorder);
				// 	$grandTotal += $itemorder['price']*$itemorder['qty'];
				// }
				// $data['Total'] = $grandTotal;
				// print_r($grandTotal);
				// die();

				// run insert model to write data to db
				if ($this->Order_model->insert_order($data) == TRUE) 
				{
					// the information has therefore been successfully saved in the db
					$i=1;
					foreach($item as $itemorder){
						$this->Order_model->insert_orderdetail($itemorder,$orderID,$i);
						$i++;
					}

					//add notification
					$this->Order_model->add_notification($orderID);

				
					
					//Send Email To Admin
					$admins=$this->Email_model->getAdmin();
					foreach($admins as $admin){
						if(isset($admin->Email) && $admin->Email!=null){
							$email_to = $admin->Email;
							$this->Email_model->send_email_CheckOut($email_to,$item,$data,$TrackingID);
						}
					}
					//End Send Email To Admin
					

					//Send Email To Customer
					$email_to = set_value('email');
					$this->Email_model->send_email_CheckOut($email_to,$item,$data,$TrackingID);
					//End Send to Customer

					//invoice
					//$this->invoice($TrackingID);

					$this->cart->destroy();
					$data['title']='CheckOut Success';
					$data['content']='FrontEnd/checkOutsuccess';
					$data['trackingID'] = $TrackingID;
					$data["orderHeader"] = $this->Order_model->getOrderByTrackingID($TrackingID);
					$data["orderDetail"] = $this->Order_model->getOrderDetailByTrackingID($TrackingID);

					$this->load->view('FrontEnd/master',$data);
				}
			}
		}
	}

	public function success($id)
	{
		if($this->session->userdata('username')){
			$data['content']='FrontEnd/checkOutsuccess';
			$data['title']='CheckOut Success';
			$this->load->model('Category_model','category');
			$data['category'] = $this->category->loadCategories();
			$data['trackingID'] = $id;
			//echo "<pre>";
			//print_r($data);
			//die();
			$this->load->view('FrontEnd/master',$data);
		}
		else{
			redirect('Login','refresh');
		}
	}

	public function invoice($id)
	{
		$this->load->model('Order_model','order');
		$this->load->model('User_model','user');
		$this->load->model('Bank_model','bank');
		$data["trackingID"] = $id;

		$data['order'] = $this->order->getOrderByTrackingID($id);
		$data['detail'] = $this->order->getOrderDetailByTrackingID($id);
		$data['bank'] = $this->bank->getBanks();
		if($this->session->userdata('userTypeID')<3)
		{
			$data['user'] = $this->user->getUserByID($data['order']->userID);
			if($data['order']->orderStatusID==1)
				$this->load->view('FrontEnd/invoiceGenerator',$data);
			else
				$this->load->view('FrontEnd/paidInvoiceGenerator',$data);
		}
		else if($data['order']->userID==$this->session->userdata('userID'))
		{
			$data['user'] = $this->user->getUserByID($this->session->userdata('userID'));
			if($data['order']->orderStatusID==1)
				$this->load->view('FrontEnd/invoiceGenerator',$data);
			else
				$this->load->view('FrontEnd/paidInvoiceGenerator',$data);
		}
		else
			$this->load->view('frontEnd/403');
	}
}
