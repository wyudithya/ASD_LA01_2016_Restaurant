<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

	//created by FS 3 Des

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('frontEnd/403');
	}

	public function view($id)
	{
		$this->load->model('Category_model','category');
		$title = $this->category->getCategoryName($id);

		$data['content']='FrontEnd/category';
		$data['title']='Vape - '.$title;

		//data for body
		$this->load->model('Product_model','product');
		//$data['newproducts'] = $this->product->getNewProducts(12,0);
		$data['categories'] = $this->category->getCategoryWithDescendant($id);
		
		//data for header
		$data['category'] = $this->category->loadCategories();
		$this->load->view('FrontEnd/master',$data);
	}
}
