<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {

	//created by FS 8 Des

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('frontEnd/403');
	}

	public function track()
	{
		$this->checkLogin();

		$this->load->model('Category_model','category');
		$title = "Track Order";

		$data['content']='FrontEnd/trackOrder';
		$data['title']='Vape - '.$title;

		//data for body
		$data_insert = $this->input->get();
		if(!empty($data_insert))
		{
			$id = $data_insert["orderNumber"];
			$this->load->model("Order_model","order");
			$data["orderHeader"] = $this->order->getOrderByTrackingID($id);
			$data["orderDetail"] = $this->order->getOrderDetailByTrackingID($id);
		}
		
		//data for header
		$data['category'] = $this->category->loadCategories();
		$this->load->view('FrontEnd/master',$data);
	}

	function history()
	{
		//created by FS 9 Des
		$this->checkLogin();

		$this->load->model('Category_model','category');
		$title = "Order History";

		$data['content']='FrontEnd/orderHistory';
		$data['title']='Vape - '.$title;

		//data for body
		$this->load->model("Order_model","order");
		$data['order'] = $this->order->getOrderHistory($this->session->userdata('userID'));
		
		//data for header
		$data['category'] = $this->category->loadCategories();
		$this->load->view('FrontEnd/master',$data);
	}

	function confirm()
	{
		$this->checkLogin();

		$this->load->model('Category_model','category');
		$title = "Order History";

		$data['content']='FrontEnd/confirmPayment';
		$data['title']='Vape - '.$title;

		//data for body
		$this->load->model("Order_model","order");
		$this->load->model("Bank_model","bank");
		$data['order'] = $this->order->getUnconfirmedOrder($this->session->userdata('userID'));
		$data["banks"] = $this->bank->getBanks();
		
		//data for header
		$data['category'] = $this->category->loadCategories();
		$this->load->view('FrontEnd/master',$data);
	}

	function confirmPayment()
	{
		$this->checkLogin();

		$data_insert = $this->input->post();
		$confirmID = "C".substr($data_insert['accountNumber'],0,2).date('Ymdhis').substr(microtime(), 2,3);
		
		$config['upload_path'] = 'assets/payment/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$config['file_name'] = $confirmID;
		$this->load->library('upload', $config);
		//$this->upload->initialize($config);
		if (!$this->upload->do_upload('userfile')){
			$error = array('error' => $this->upload->display_errors());
			print_r($error);
			exit();
		}else{
			$img_file = ($this->upload->data());
			//$this->load->library('image_lib');
			//$config_t['new_image']  = $img_file["file_path"];
		}

		$this->load->model("Payment_model","payment");
		$this->payment->confirmPayment($confirmID, $data_insert);
		$this->load->model("Email_model");
		$this->Email_model->confirmPayment($data_insert);
		redirect(base_url()."Order/history");
	}

	private function checkLogin()
	{
		if($this->session->userdata('username')==null||$this->session->userdata('username')=="")
		{
			die();
			redirect(base_url()."Login");
		}
	}
}
