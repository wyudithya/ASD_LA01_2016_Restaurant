<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
 		parent::__construct();
		$this->load->library('form_validation');
		$this->load->database();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('Login_model');
	}
	public function input(){
		$this->form_validation->set_rules('username', 'Username', 'required|max_length[100]');					
		$this->form_validation->set_rules('password', 'Password', 'required|max_length[100]');

		$this->load->model('Login_model','login');
			
		$this->form_validation->set_error_delimiters('<br /><span class="error">', '</span>');
	
		if ($this->form_validation->run() == FALSE) // validation hasn't been passed
		{
			$data['content']='FrontEnd/login';
			$data['title']='Login';
			$this->load->model('Category_model','category');
			$data['category'] = $this->category->getAllCategory();
			$data['error'] = "";
			
			$this->load->view('FrontEnd/master',$data);
		}
		else
		{
			$query = $this->login->login(set_value('username'),set_value('password'));
/*			print_r($query);*/
			if ($query) // the information has therefore been successfully saved in the db
			{
				/*print_r('hi '.set_value('username'));
				/*print_r($row);*/
				//print_r($row['Name']);
				//echo $query->row(0)->Name;
				$data = array (
					'username' => $query->row(0)->Username,
					'userType' => $query->row(0)->UserType,
					'userTypeID' => $query->row(0)->UserTypeID,
					'userID' => $query->row(0)->UserID
				);
				$this->session->set_userdata($data);

				redirect('Home','refresh');
			}
			else
			{
				$data['content']='FrontEnd/login';
				$data['title']='Login';
				$this->load->model('Category_model','category');
				$data['category'] = $this->category->getAllCategory();
				$data['error'] = "Check your email address and password combination.";
				
				$this->load->view('FrontEnd/master',$data);
			}
		}
	}
	public function logout(){
		$this->session->unset_userdata('username');
		$this->cart->destroy();
		redirect('Home','refresh');
	}
	public function index()
	{
		//modified by FS 8 Des
		$this->checkLogin();
		$data['content']='FrontEnd/login';
		$data['title']='Login';
		
		//data for header
		$this->load->model('Category_model','category');
		//modified by FS 3 Des
		//ini load category yang udah ada sub
		$data['category'] = $this->category->loadCategories();
		$this->load->view('FrontEnd/master',$data);
	}
	private function checkLogin()
	{
		//added by FS 8 Des
		//user kalo udah login, nembak halaman ini, ga bisa
		if($this->session->userdata('username')!=null&&$this->session->userdata('username')!="")
		{
			redirect(base_url()."Home");
		}
	}
}

