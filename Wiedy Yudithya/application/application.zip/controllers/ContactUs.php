<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ContactUs extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
 		parent::__construct();
		$this->load->library('form_validation');
		$this->load->database();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('Contactus_model');
		$this->load->model('Email_model');
	}	

	public function input(){
		$this->load->library('recaptcha');
		$captcha_answer = $this->input->post('g-recaptcha-response');

		// Verify user's answer
		$response = $this->recaptcha->verifyResponse($captcha_answer);

		$this->form_validation->set_rules('name', 'Name', 'required|max_length[100]');			
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|max_length[100]');		
		$this->form_validation->set_rules('phone_number', 'Phone Number', 'required|is_numeric|max_length[100]');	
		$this->form_validation->set_rules('subject', 'Subject', 'required|max_length[100]');					
		$this->form_validation->set_rules('message', 'Message', 'required|max_length[1000]');			
		//$this->form_validation->set_error_delimiters('<br /><span class="error">', '</span>');
		
		if($response['success']==FALSE)
			$data['recaptcha_error'] = "Please fill out a CAPTCHA";

		if ($this->form_validation->run() == FALSE || $response['success']==FALSE) 
		// validation hasn't been passed
		{
			$data['content']='FrontEnd/contactus';
			$data['title']='Contact Us';
			$this->load->model('Category_model','category');
			//modified by FS 3 Des
			//ini load category yang udah ada sub
			$data['category'] = $this->category->getAllCategory();
			
			$this->load->view('FrontEnd/master',$data);
		}
		else // passed validation proceed to post success logic
		{
		 	// build array for the model
		 	$ContactID = "C".substr(set_value('name'),0,2).date('Ymdhis').substr(microtime(), 2,3);
		 	$NotifID = "N".substr(set_value('name'),0,2).date('Ymdhis').substr(microtime(), 2,3);
			$form_data = array(
							'contactid' => $ContactID,					       
					       	'name' => set_value('name'),
					       	'email' => set_value('email'),
					       	'phone_number' => set_value('phone_number'),
					       	'subject' => set_value('subject'),
					       	'message' => set_value('message')
						);
					
			// run insert model to write data to db
			$notif_data = array(
							'notifid' => $NotifID,
							'notiftypeid' => 3,
							'referenceid' => $ContactID				
						);
			if ($this->Contactus_model->SaveForm($form_data) == TRUE && $this->Contactus_model->NotifInsert($notif_data) == TRUE) // the information has therefore been successfully saved in the db
			{

				$this->Email_model->contactForm($form_data);
				redirect('Home');
			}
		}
	}

	public function index()
	{
		$data['content']='FrontEnd/contactus';
		$data['title']='Contact Us';

		//data for header
		$this->load->model('Category_model','category');
		//modified by FS 3 Des
		//ini load category yang udah ada sub
		$data['category'] = $this->category->loadCategories();
		
		$this->load->view('FrontEnd/master',$data);
	}
}
