<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		if($this->session->userdata('username')){
			//data for header
			$this->load->model('Category_model','category');
			//modified by FS 3 Des
			$data['category'] = $this->category->loadCategories();
			$data['content']='FrontEnd/cartTest';
			$data['title']='Cart';
			$this->load->view('FrontEnd/master',$data);
		}
		else{
			redirect('Login','refresh');
		}

	}
	public function update(){
		$i = 1;
		$row = $i.'[rowid]';
		$qty = $i.'[qty]';
		while($this->input->post($row)){
			$data = array(
               'rowid' => $this->input->post($row),
               'qty'   => $this->input->post($qty)
            );
			$this->cart->update($data); 
			$i++;
			$row = $i.'[rowid]';
			$qty = $i.'[qty]';
		}
		redirect('Cart','refresh');
	}
	public function delete($rowid){
			$data = array(
               'rowid' => $rowid,
               'qty'   => 0
            );
			$this->cart->update($data); 

		redirect('Cart','refresh');
	}
}
