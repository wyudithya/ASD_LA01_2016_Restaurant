<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banner_model extends CI_Model {

	function getAllBanner()
	{
		$result = array();
		$queryString = "SELECT BannerID,msbanner.ProductID,ProductName,CategoryName, Photo FROM msproduct JOIN mscategory ON msproduct.CategoryID = mscategory.CategoryID JOIN msbanner on msproduct.ProductID = msbanner.ProductID WHERE msbanner.AuditedActivity <> 'D'";
		$query = $this->db->query($queryString);
		
		for($i=0;$i<$query->num_rows();$i++)
		{ 
			$temp = new stdClass();
			$temp->BannerID = $query->row($i)->BannerID;
			$temp->ProductID = $query->row($i)->ProductID;
			$arr = explode(";", $query->row($i)->Photo);
			$temp->photo = $arr[0];
			$temp->ProductName = $query->row($i)->ProductName;
			$temp->CategoryName = $query->row($i)->CategoryName;
			array_push($result, $temp);			
		}
		return $result;
	}


	function getBannerByID($id){
			$temp = new stdClass();
			$queryString = "SELECT BannerID,msbanner.ProductID,msproduct.CategoryID FROM msproduct JOIN mscategory ON msproduct.CategoryID = mscategory.CategoryID JOIN msbanner on msproduct.ProductID = msbanner.ProductID 
			WHERE msbanner.AuditedActivity <> 'D' and BannerID = ?";
			$query = $this->db->query($queryString,array($id));
				$i = 0;
				$temp = new stdClass();
				$temp->BannerID = $query->row($i)->BannerID;
				$temp->ProductID = $query->row($i)->ProductID;
				$temp->CategoryID = $query->row($i)->CategoryID;
		return $temp;

	}

	function deleteBannerByID($id){
	$queryString = "UPDATE msbanner  SET AuditedActivity = 'D', AuditedUser = ?, AuditedTime = CURRENT_TIMESTAMP where BannerID = ? ";
	$query = $this->db->query($queryString,array($this->session->userdata('userID'),$id));
	redirect('BackEnd/Banner','refresh');
						
	}


	function updateBannerByID($id,$data){

	$queryString = "UPDATE msbanner  SET AuditedActivity = 'U', AuditedUser = ?, AuditedTime = CURRENT_TIMESTAMP , ProductID = ? where BannerID = ? ";
	$query = $this->db->query($queryString,array($this->session->userdata('userID'),$data['ddlproduct'],$id));
	redirect('BackEnd/Banner','refresh');
						
	}

	function AddBanner($data)
	{
		$BannerID = "B".substr($data['ddlproduct'],0,2).date('Ymdhis').substr(microtime(), 2,3);
		$queryString = "INSERT INTO msbanner(BannerID,AuditedActivity,AuditedTime,AuditedUser,ProductID)
		 Values(?,'I',CURRENT_TIMESTAMP,?,?)";
		$query = $this->db->query($queryString,array($BannerID,$this->session->userdata('userID'),$data['ddlproduct']));
		redirect('BackEnd/Banner/','refresh');
	}
}

/* End of file Banner_model.php */
/* Location: ./application/models/Banner_model.php */