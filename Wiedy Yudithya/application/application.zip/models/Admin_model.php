<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Temp{}
class Admin_model extends CI_Model
{
	function __construct() 
	{
		parent::__construct();
	}

	function initializeTemplate()
	{
		$data = [];
		$data["orderStatus"] = $this->loadOrderStatus();
		$data["categories"] = $this->loadCategories();
		$data["contactNotification"] = $this->getContactNotifications();
		$data["newOrderCount"] = $this->getOrderNotificationCount();
		$data["orderCount"] = $this->getOrderCount(count($data["orderStatus"]));
		$data["paymentNotification"] = $this->getPaymentNotifications();
		return $data;
	}

	function getPaymentNotifications()
	{
		$result = array();
		$queryString = "SELECT a.NotificationID, a.ReferenceID, a.Time, a.IsRead, d.UserID, d.Name, b.IsProcessed, c.Total, b.OrderID FROM trnotification a JOIN mspayment b ON a.ReferenceID = b.PaymentID JOIN trorder c ON b.OrderID = c.OrderID JOIN msuser d ON c.UserID=d.UserID WHERE NotificationTypeID = 2 AND a.AuditedActivity <> 'D' AND IsProcessed='0'";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new Temp();
			$temp->notificationID = $query->row($i)->NotificationID;
			$temp->referenceID = $query->row($i)->ReferenceID;
			$temp->time = $this->getTimeString($query->row($i)->Time);
			$temp->isRead = $query->row($i)->IsRead;
			$temp->name = $query->row($i)->Name;
			$temp->userID = $query->row($i)->UserID;
			$temp->orderID = $query->row($i)->OrderID;
			$temp->total = $query->row($i)->Total;
			$temp->isProcessed = ($query->row($i)->IsProcessed=='1')?true:false;
			array_push($result, $temp);
		}
		return $result;
	}
	
	function loadOrderStatus()
	{

		$result = array();
		$queryString = "SELECT * FROM ltorderstatus";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new Temp();
			$temp->orderStatus = $query->row($i)->OrderStatus;
			$temp->orderStatusID =$query->row($i)->OrderStatusID;
			array_push($result, $temp);
		}
		return $result;
	}

	function loadCategories()
	{
		$result =array();
		$queryString = "SELECT a.CategoryID, a.CategoryName, a.ChildName, a.ChildID, COUNT(ProductID) AS ProductCount FROM (SELECT b.CategoryID, b.CategoryName, c.CategoryName AS ChildName, c.CategoryID AS ChildID FROM mscategory b LEFT JOIN mscategory c ON b.CategoryID = c.ParentCategoryID WHERE b.AuditedActivity<>'D' AND b.IsSubCategory='0') AS a LEFT JOIN msproduct d ON d.CategoryID = a.CategoryID GROUP BY a.CategoryID, a.CategoryName, a.ChildName, a.ChildID";
		$query = $this->db->query($queryString);
		if($query->num_rows()==0)
			return $result;
		$tempID = 0;
		$cat;
		for($i=0;$i<$query->num_rows();$i++)
		{
			if($tempID!=$query->row($i)->CategoryID)
			{
				$cat = new stdClass();
				$cat->categoryID=$query->row($i)->CategoryID;
				$cat->categoryName = $query->row($i)->CategoryName;
				$cat->childCategory = array();
				$tempID = $cat->categoryID;
				if($query->row($i)->ChildID==NULL)
					$cat->productCount = $query->row($i)->ProductCount;
				else
				{
					$temp = new stdClass();
					$temp->categoryID=$query->row($i)->ChildID;
					$temp->categoryName = $query->row($i)->ChildName;
					$temp->productCount = $query->row($i)->ProductCount;
					array_push($cat->childCategory, $temp);
				}
				array_push($result, $cat);
			}
			else
			{
				$temp = new stdClass();
				$temp->categoryID=$query->row($i)->ChildID;
				$temp->categoryName = $query->row($i)->ChildName;
				$temp->productCount = $query->row($i)->ProductCount;
				array_push($cat->childCategory, $temp);
			}
		}
		return $result;
	}

	function getContactNotifications()
	{
		$result = array();
		$queryString = "SELECT NotificationID, ReferenceID, trnotification.Time, UserID, IsRead, Name, Email, PhoneNumber, Message FROM trnotification JOIN mscontact ON trnotification.ReferenceID = mscontact.ContactID WHERE NotificationTypeID = 3 AND trnotification.AuditedActivity <> 'D'";
		//ini sengaja ambil semua, nanti filter isRead nya pas di view tujuannya biar pas klik msg di kanan atas ada semuanya dulu
		//by FS
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new Temp();
			$temp->notificationID = $query->row($i)->NotificationID;
			$temp->referenceID = $query->row($i)->ReferenceID;
			$temp->time = $this->getTimeString($query->row($i)->Time);
			$temp->userID = $query->row($i)->UserID;
			$temp->isRead = $query->row($i)->IsRead;
			$temp->name = $query->row($i)->Name;
			$temp->email = $query->row($i)->Email;
			$temp->phoneNumber = $query->row($i)->PhoneNumber;
			$temp->message = $this->generatePreview($query->row($i)->Message);
			array_push($result, $temp);
		}
		return $result;
	}

	function getOrderNotificationCount()
	{
		$queryString = "SELECT COUNT(NotificationID) AS count FROM trnotification WHERE NotificationTypeID = 1 AND IsRead = '0' AND AuditedActivity <> 'D'";
		$query=$this->db->query($queryString);
		return $query->row(0)->count;
	}

	function getOrderCount($orderTypeCount)
	{
		$result = array();
		for($i=1;$i<=$orderTypeCount;$i++)
		{
			$queryString = "SELECT COUNT(OrderID) AS count FROM trorder WHERE OrderStatusID = ? AND AuditedActivity <> 'D'";
			$query = $this->db->query($queryString,array($i));
			array_push($result, $query->row(0)->count);
		}
		return $result;
	}
	
	function generatePreview($msg)
	{
		$arr = explode(" ", $msg);
		$Message = "";
		$charCount = 0;
		
		for($i = 0 ; $i < 15; $i++)
		{
			if($i==count($arr))
				break;
			$charCount += strlen($arr[$i]);
			if($charCount>60)
				break;
			$Message = $Message . " ". $arr[$i];
		}
		$Message = $Message . "...";
		return $Message;
	}
	function getTimeString($t)
	{
		$t = strtotime($t);
		$ret = "";
		if(date('z')>date('z',$t))
		{
			$ret = date('d-M-Y',$t);
		}
		else
		{
			$ret = date('H:i',$t);
		}
		return $ret;
	}
}