<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Detail{}
class Order_model extends CI_Model
{
	function __construct() 
	{
		parent::__construct();
	}
	function getOrderTypeNameByID($id)
	{
		$queryString = "SELECT * FROM ltorderstatus WHERE OrderStatusID = ?";
		$query = $this->db->query($queryString,array($id));
		return $query->row(0)->OrderStatus;
	}
	function getOrderDetailByID($id)
	{
		$result = array();
		$queryString = "SELECT a.ProductID, a.Qty, b.ProductName, a.Price, a.Discount, c.CategoryName, b.Color FROM trorderdetail a JOIN msproduct b ON a.ProductID = b.ProductID JOIN mscategory c ON b.CategoryID = c.CategoryID WHERE a.OrderID = ?";
		$query = $this->db->query($queryString,array($id));
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->productID = $query->row($i)->ProductID;
			$temp->qty = $query->row($i)->Qty;
			$temp->productName = $query->row($i)->ProductName;
			$temp->price = $query->row($i)->Price;
			$temp->discount = $query->row($i)->Discount;
			$temp->category = $query->row($i)->CategoryName;
			$temp->color = $query->row($i)->Color;
			$temp->finalPrice = ($temp->qty*$temp->price*(100-$temp->discount))/100;
			array_push($result, $temp);
		}
		return $result;
	}

	function getNextStep($orderStatus,$paymentType)
	{
		//modified by FS 5 Nov
		$queryString = "SELECT * FROM ltorderstatus";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			if($query->row($i)->OrderStatus == $orderStatus)
			{
				if($paymentType=="Cash on Delivery"&&$i==0)
				{
					return $query->row($i+2)->OrderStatus;
				}
				if($i<$query->num_rows()-1)
					return $query->row($i+1)->OrderStatus;
				else
					return "";
			}
		}
	}

	function goToNextStep($orderID, $currentStep)
	{
		$currentStep++;
		//modified by FS 5 Nov, add audited
		$queryString = "UPDATE trorder SET OrderStatusID = ?, AuditedActivity = 'U', AuditedTime=CURRENT_TIMESTAMP, AuditedUser=? WHERE OrderID = ?";
		$query = $this->db->query($queryString,array($currentStep,$this->session->userdata('userID'),$orderID));
	}

	function getOrderByID($id)
	{
		$temp = new Temp();
		$queryString = "SELECT a.OrderID, a.UserID, d.PaymentType, c.OrderStatus, a.TrackingID, a.Notes, a.ReceivedDate, a.DeliveryDate, g.Name, a.OrderStatusID, a.Address, a.RecipientName, a.ShippingCost, a.Email, a.PhoneNumber,a.OrderDate, a.NomorResi FROM trorder a JOIN ltorderstatus c ON a.OrderStatusID = c.OrderStatusID JOIN ltpaymenttype d ON a.PaymentTypeID = d.PaymentTypeID JOIN msuser g ON a.UserID = g.UserID WHERE a.AuditedActivity <> 'D' AND a.OrderID = ?";
		$query = $this->db->query($queryString,array($id));
		$i = 0;
		$temp->orderID = $query->row($i)->OrderID;
		$temp->userID = $query->row($i)->UserID;
		$temp->orderStatusID = $query->row($i)->OrderStatusID;
		$temp->paymentType = $query->row($i)->PaymentType;
		$temp->orderStatus = $query->row($i)->OrderStatus;
		$temp->trackingID = $query->row($i)->TrackingID;
		$temp->notes = $query->row($i)->Notes;
		$temp->address = $query->row($i)->Address;
		//modified by FS 12 Des
		$temp->nomorResi = $query->row($i)->NomorResi;
		//modified by FS 9 Des
		$temp->email = $query->row($i)->Email;
		$temp->phoneNumber = $query->row($i)->PhoneNumber;
		$temp->recipientName = $query->row($i)->RecipientName;
		$temp->orderDate = $this->getFormattedDate($query->row($i)->OrderDate);
		$temp->receivedDate = $this->getFormattedDate($query->row($i)->ReceivedDate);
		$temp->deliveryDate = $this->getFormattedDate($query->row($i)->DeliveryDate);
		$temp->shippingCost = $query->row($i)->ShippingCost;
		$temp->name = $query->row($i)->Name;
		return $temp;
	}

	function removeFromNotification($id)
	{
		//audited time 
		$queryString = "UPDATE trnotification SET IsRead = 1, AuditedUser = ?, AuditedTime = CURRENT_TIMESTAMP, AuditedActivity = 'U' WHERE ReferenceID = ?";
		$query = $this->db->query($queryString,array($this->session->userdata('userID'),$id));
	}

	function getOrderByStatus($status)
	{
		$result = array();
		// $queryString = "SELECT a.OrderID, a.UserID, d.PaymentType, c.OrderStatus, a.TrackingID, a.Notes, a.Address, a.RecipientName, a.ReceivedDate, a.DeliveryDate, e.ProductName, e.Price, e.Discount, f.CategoryName, g.Name, b.Qty FROM trorder a JOIN trorderdetail b ON a.OrderID = b.OrderID JOIN ltorderstatus c ON a.OrderStatusID = c.OrderStatusID JOIN ltpaymenttype d ON a.PaymentTypeID = d.PaymentTypeID JOIN msproduct e ON b.ProductID = e.ProductID JOIN mscategory f ON e.CategoryID = f.CategoryID JOIN msuser g ON a.UserID = g.UserID WHERE a.AuditedActivity <> 'D'";
		$queryString = "SELECT a.OrderID, a.UserID, d.PaymentType, c.OrderStatus, a.TrackingID, a.Notes, a.ReceivedDate, a.DeliveryDate, g.Name, a.OrderDate, a.ShippingCost, h.IsRead FROM trorder a JOIN ltorderstatus c ON a.OrderStatusID = c.OrderStatusID JOIN ltpaymenttype d ON a.PaymentTypeID = d.PaymentTypeID JOIN msuser g ON a.UserID = g.UserID JOIN trnotification h ON a.OrderID = h.ReferenceID WHERE a.AuditedActivity <> 'D' AND a.OrderStatusID = ?";
		$query = $this->db->query($queryString,array($status));
		$tempID = "";
		$temp = new stdClass();
		for($i=0;$i<$query->num_rows();$i++)
		{
			if($tempID!=$query->row($i)->OrderID)
			{
				$tempID = $query->row($i)->OrderID;
				$temp = new stdClass();
				$temp->orderID = $query->row($i)->OrderID;
				$temp->userID = $query->row($i)->UserID;
				$temp->paymentType = $query->row($i)->PaymentType;
				$temp->orderStatus = $query->row($i)->OrderStatus;
				$temp->trackingID = $query->row($i)->TrackingID;
				$temp->notes = $query->row($i)->Notes;
				$temp->orderDate = $this->getFormattedDate($query->row($i)->OrderDate);
				$temp->deliveryDate = $this->getFormattedDate($query->row($i)->DeliveryDate);
				$temp->name = $query->row($i)->Name;
				//modified by FS 15 Des
				$temp->isRead = $query->row($i)->IsRead;
				//modified by FS 13 Des
				$temp->shippingCost = $query->row($i)->ShippingCost;
				array_push($result, $temp);
			}
		}
		return $result;
	}

	function getAllOrders()
	{
		$result = array();
		// $queryString = "SELECT a.OrderID, a.UserID, d.PaymentType, c.OrderStatus, a.TrackingID, a.Notes, a.Address, a.RecipientName, a.ReceivedDate, a.DeliveryDate, e.ProductName, e.Price, e.Discount, f.CategoryName, g.Name, b.Qty FROM trorder a JOIN trorderdetail b ON a.OrderID = b.OrderID JOIN ltorderstatus c ON a.OrderStatusID = c.OrderStatusID JOIN ltpaymenttype d ON a.PaymentTypeID = d.PaymentTypeID JOIN msproduct e ON b.ProductID = e.ProductID JOIN mscategory f ON e.CategoryID = f.CategoryID JOIN msuser g ON a.UserID = g.UserID WHERE a.AuditedActivity <> 'D'";
		$queryString = "SELECT a.OrderID, a.UserID, d.PaymentType, c.OrderStatus, a.TrackingID, a.Notes, a.ReceivedDate, a.DeliveryDate, g.Name, a.OrderDate, a.ShippingCost, h.IsRead FROM trorder a JOIN ltorderstatus c ON a.OrderStatusID = c.OrderStatusID JOIN ltpaymenttype d ON a.PaymentTypeID = d.PaymentTypeID JOIN msuser g ON a.UserID = g.UserID JOIN trnotification h ON a.OrderID = h.ReferenceID WHERE a.AuditedActivity <> 'D'";
		$query = $this->db->query($queryString);
		$tempID = "";
		$temp = new stdClass();
		for($i=0;$i<$query->num_rows();$i++)
		{
			if($tempID!=$query->row($i)->OrderID)
			{
				$tempID = $query->row($i)->OrderID;
				$temp = new stdClass();
				$temp->orderID = $query->row($i)->OrderID;
				$temp->userID = $query->row($i)->UserID;
				$temp->paymentType = $query->row($i)->PaymentType;
				$temp->orderStatus = $query->row($i)->OrderStatus;
				$temp->trackingID = $query->row($i)->TrackingID;
				$temp->notes = $query->row($i)->Notes;
				//modified by FS 9 Des
				$temp->orderDate = $this->getFormattedDate($query->row($i)->OrderDate);
				$temp->deliveryDate = $this->getFormattedDate($query->row($i)->DeliveryDate);
				$temp->name = $query->row($i)->Name;
				//modified by FS 15 Des
				$temp->isRead = $query->row($i)->IsRead;
				//modified by FS 13 Des
				$temp->shippingCost = $query->row($i)->ShippingCost;
				array_push($result, $temp);
			}
		}
		return $result;
	}
	function loadOrderStatus()
	{

		$result = array();
		$queryString = "SELECT * FROM ltorderstatus";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->orderStatus = $query->row($i)->OrderStatus;
			$temp->orderStatusID =$query->row($i)->OrderStatusID;
			array_push($result, $temp);
		}
		return $result;
	}

	function getOrderDetailByTrackingID($id)
	{
		//added by FS 8 Des
		$result = array();
		$queryString = "SELECT a.ProductID, a.Qty, b.ProductName, a.Price, a.Discount, c.CategoryName, b.Color FROM trorderdetail a JOIN msproduct b ON a.ProductID = b.ProductID JOIN mscategory c ON b.CategoryID = c.CategoryID JOIN trorder d ON a.OrderID = d.OrderID WHERE d.TrackingID = ?";
		$query = $this->db->query($queryString,array($id));
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->productID = $query->row($i)->ProductID;
			$temp->qty = $query->row($i)->Qty;
			$temp->productName = $query->row($i)->ProductName;
			$temp->price = $query->row($i)->Price;
			$temp->discount = $query->row($i)->Discount;
			$temp->category = $query->row($i)->CategoryName;
			$temp->color = $query->row($i)->Color;
			$temp->finalPrice = ($temp->qty*$temp->price*(100-$temp->discount)/100);
			array_push($result, $temp);
		}
		return $result;
	}
	function getOrderByTrackingID($id)
	{
		//added by FS 8 Des
		$temp = new stdClass();
		$queryString = "SELECT a.OrderID, a.UserID, d.PaymentType, c.OrderStatus, a.TrackingID, a.Notes, a.ReceivedDate, a.DeliveryDate, g.Name, a.OrderStatusID, a.Address, a.RecipientName, a.ShippingCost, a.Email, a.PhoneNumber, a.OrderDate, a.Total, a.NomorResi FROM trorder a JOIN ltorderstatus c ON a.OrderStatusID = c.OrderStatusID JOIN ltpaymenttype d ON a.PaymentTypeID = d.PaymentTypeID JOIN msuser g ON a.UserID = g.UserID WHERE a.AuditedActivity <> 'D' AND a.TrackingID = ?";
		$query = $this->db->query($queryString,array($id));
		if($query->num_rows()==0)
			return $temp;
		$i = 0;
		$temp->orderID = $query->row($i)->OrderID;
		$temp->userID = $query->row($i)->UserID;
		$temp->orderStatusID = $query->row($i)->OrderStatusID;
		$temp->paymentType = $query->row($i)->PaymentType;
		$temp->orderStatus = $query->row($i)->OrderStatus;
		$temp->trackingID = $query->row($i)->TrackingID;
		$temp->notes = $query->row($i)->Notes;
		$temp->address = $query->row($i)->Address;
		//modified by FS 12 Des
		$temp->nomorResi = $query->row($i)->NomorResi;
		//modified by FS 9 Des
		$temp->orderDate = $this->getFormattedDate($query->row($i)->OrderDate);
		$temp->email = $query->row($i)->Email;
		$temp->total = $query->row($i)->Total;
		$temp->phoneNumber = $query->row($i)->PhoneNumber;
		$temp->recipientName = $query->row($i)->RecipientName;
		$temp->receivedDate = $this->getFormattedDate($query->row($i)->ReceivedDate);
		$temp->deliveryDate = $this->getFormattedDate($query->row($i)->DeliveryDate);
		$temp->shippingCost = $query->row($i)->ShippingCost;
		$temp->name = $query->row($i)->Name;
		return $temp;
	}

	function getOrderHistory($id)
	{
		//added by FS 9 Des
		$result = array();
		$queryString = "SELECT a.OrderID, d.PaymentType, c.OrderStatus, a.TrackingID, a.Notes, a.ReceivedDate, a.DeliveryDate, a.Total, a.OrderDate, a.NomorResi, a.ShippingCost FROM trorder a JOIN ltorderstatus c ON a.OrderStatusID = c.OrderStatusID JOIN ltpaymenttype d ON a.PaymentTypeID = d.PaymentTypeID WHERE a.AuditedActivity <> 'D' AND a.UserID = ?";
		$query = $this->db->query($queryString,array($id));
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->orderID = $query->row($i)->OrderID;
			$temp->orderID = $query->row($i)->OrderID;
			$temp->paymentType = $query->row($i)->PaymentType;
			$temp->orderStatus = $query->row($i)->OrderStatus;
			$temp->trackingID = $query->row($i)->TrackingID;
			$temp->notes = $query->row($i)->Notes;
			$temp->orderDate = $this->getFormattedDate($query->row($i)->OrderDate);
			$temp->receivedDate = $this->getFormattedDate($query->row($i)->ReceivedDate);
			$temp->deliveryDate = $this->getFormattedDate($query->row($i)->DeliveryDate);
			$temp->total = $query->row($i)->Total;
			//modified by FS 12 Des
			$temp->nomorResi = $query->row($i)->NomorResi;
			//modified by FS 13 Des
			$temp->shippingCost = $query->row($i)->ShippingCost;
			array_push($result, $temp);
		}
		return $result;
	}

	function getUnconfirmedOrder($id)
	{
		$result = array();
		$queryString = "SELECT OrderID, Total, TrackingID, ShippingCost FROM trorder WHERE UserID = ? AND OrderStatusID = 1 AND AuditedActivity <> 'D'";
		$query = $this->db->query($queryString,array($id));
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->orderID = $query->row($i)->OrderID;
			$temp->total = $query->row($i)->Total;
			$temp->trackingID = $query->row($i)->TrackingID;
			//modified by FS 13 Des
			$temp->shippingCost = $query->row($i)->ShippingCost;
			array_push($result, $temp);
		}
		return $result;
	}

	function getFormattedDate($t)
	{
		//modified by FS 9 Des
		$t = strtotime($t);
		$ret = "";
		if($t==NULL||$t=="")
			return "";
		else
			$ret = date('H:i d-M-Y',$t);
		return $ret;
	}


	function insert_order($data)
	{
		///echo "<pre>";
		//print_r($data);
		//$queryString = "INSERT INTO trorder('OrderID','UserId','PaymentTypeID','OrderStatusID','TrackingID','Address','Email','PhoneNumber','RecipientName','AuditedActivity') Values('or1','".$data['UserID']."',1,5,21321,'".$data['Notes']."','".$data['address']."','".$data['Email']."','".$data['PhoneNumber']."','".$data['RecipientName']."','I')";
		$queryString = "INSERT INTO trorder VALUES(?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP, '', '', ?, CURRENT_TIMESTAMP, 'I', ?,?,?,?)";
		$query = $this->db->query($queryString,array($data['OrderID'],$data['UserID'],$data['PaymentTypeID'],$data['OrderStatusID'],$data['TrackingID'],$data['Notes'],$data['address'],$data['Email'],$data['PhoneNumber'],$data['RecipientName'],$this->session->userdata('userID'),$data['ShippingCost'],$data['Total'],'',$data['Service']));

		// $queryString = "INSERT INTO `trorder`(`OrderID`, `UserID`, `PaymentTypeID`, `OrderStatusID`, `TrackingID`, `Notes`, `Address`, `Email`, `PhoneNumber`, `RecipientName`,`OrderDate`,`AuditedTime`,`AuditedActivity`,'ShippingCost', `Total`,'NomorResi','Service') VALUES ('".$data['OrderID']."','".$data['UserID']."','".$data['PaymentTypeID']."','".$data['OrderStatusID']."','".$data['TrackingID']."','".$data['Notes']."','".$data['address']."','".$data['Email']."','".$data['PhoneNumber']."','".$data['RecipientName']."',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'I',".$data['ShippingCost'].",".$data['Total'].",'','".$data['Service']."')";
		// $query = $this->db->query($queryString);
		return $query;
	}


	function insert_orderdetail($data,$orderID,$i)
	{
		//$queryString = "INSERT INTO trorder('OrderID','UserId','PaymentTypeID','OrderStatusID','TrackingID','Address','Email','PhoneNumber','RecipientName','AuditedActivity') Values('or1','".$data['UserID']."',1,5,21321,'".$data['Notes']."','".$data['address']."','".$data['Email']."','".$data['PhoneNumber']."','".$data['RecipientName']."','I')";
		$digit =  str_pad($i, 2, "0", STR_PAD_LEFT);
		$orderDetailID = "D".$digit.date('Ymdhis').substr(microtime(), 2,3);
		$discount = $data['discount'];
		if($data['discount']>0)
			$price = $data['price']*100/(100-$data['discount']);
		else
			$price = $data['price'];
		//$price/=$data['qty'];
		$queryString = "INSERT INTO `trorderdetail`(`OrderDetailID`, `OrderID`, `ProductID`, `Qty`,`Discount`, `Price`) VALUES ('".$orderDetailID."','".$orderID."','".$data['id']."','".$data['qty']."','".$discount."','".$price."')";
		$query = $this->db->query($queryString);
		return $query;
	}

	function add_notification($orderID){
		$NotificationID = "N".substr($orderID,0,2).date('Ymdhis').substr(microtime(), 2,3);
		$queryString = "INSERT INTO trnotification VALUES(?, 1, ?, '0',CURRENT_TIMESTAMP, ?, CURRENT_TIMESTAMP, 'I')";
		$query = $this->db->query($queryString, array($NotificationID, $orderID, $this->session->userdata('userID')));
		return $query;
	}

	function insertNomorResi($orderID, $nomorResi,$deliveryDate)
	{
		$queryString = "UPDATE trorder SET NomorResi = ?, DeliveryDate = ?, AuditedUser = ?, AuditedActivity = 'U', AuditedTime=CURRENT_TIMESTAMP WHERE OrderID = ?";
		$this->db->query($queryString,array($nomorResi,$deliveryDate, $this->session->userdata('userID'), $orderID));
	}

	function insertReceivedDate($orderID, $receivedDate)
	{
		$queryString = "UPDATE trorder SET ReceivedDate = ?, AuditedTime = CURRENT_TIMESTAMP, AuditedUser = ?, AuditedActivity = 'U' WHERE OrderID = ?";
		$this->db->query($queryString, array($receivedDate, $this->session->userdata('userID'),$orderID));
	}
}