<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_model extends CI_Model
{
	//created by FS 11 Des
	//pake model aja biar lebih gampang pake nya
	function __construct() 
	{
		parent::__construct();
		$this->load->library('email');
	}
	function sendInvoice($trackingID,$email_to){
		/*
		$config['protocol'] = 'smtp';
	    $config['smtp_host'] = 'ssl://bigcorn.qwords.net';
	    $config['smtp_port'] = '465';
	    $config['smtp_user'] = 'fs@ferware.com'; // itu pake smtp gmail jadi gw kasi email gmail gtu. 
	    $config['smtp_pass'] = 'ferware!!!';
	    $config['mailtype'] = 'html';
	    $config['charset'] = 'iso-8859-1';
	    $config['wordwrap'] = TRUE;
	    $config['newline'] = "\r\n";
		$this->email->initialize($config);
		*/
		
		//$this->email->from('no-reply@54vape.com', '(No-Reply)Customer Service 54 Vape'); // jadi nama pengirim itu ganti jadi yang di sana.
		$config['protocol'] = 'smtp';
		$config['smtp_host'] = 'ssl://bigcorn.qwords.net';
	    $config['smtp_port'] = '465';
	    $config['smtp_user'] = 'fs@ferware.com'; // itu pake smtp gmail jadi gw kasi email gmail gtu. 
	    $config['smtp_pass'] = 'ferware!!!';
	    // $config['smtp_host'] = 'ssl://smtp.gmail.com';
	    // $config['smtp_port'] = '465';
	    // $config['smtp_user'] = '54vapedummy@gmail.com'; // itu pake smtp gmail jadi gw kasi email gmail gtu. 
	    // $config['smtp_pass'] = 'adminnyavape';
	    $config['mailtype'] = 'html';
	    $config['charset'] = 'iso-8859-1';
	    $config['wordwrap'] = TRUE;
	    $config['newline'] = "\r\n";

		$this->email->initialize($config);
		$this->email->clear(TRUE);

		$this->email->from('no-reply@54vape.com', '(No-Reply)Customer Service 54 Vape'); // jadi nama pengirim itu ganti jadi yang di sana.
		$this->email->to($email_to); 
		
		//$this->email->cc('ferico55@gmail.com'); 
		//$this->email->bcc('anwijaya@binus.edu'); 

		$this->email->subject('Invoice');
		$this->email->message('Please download the attachment for more details about your invoice');

		$myfile = fopen("invoice/".$trackingID.".pdf", "w+");
		print_r(base_url());

		fwrite($myfile, stream_get_contents(fopen(base_url()."CheckOut/invoice/".$trackingID,"r")));
		fclose($myfile);

		$this->email->attach(base_url()."invoice/".$trackingID.".pdf");

		$this->email->send();
	}
	function getAdmin(){
		$result = array();
		$queryString = "SELECT UserID, Name, Email FROM msuser WHERE UserTypeID IN (1,2) AND AuditedActivity <> 'D'";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->UserID = $query->row($i)->UserID;
			$temp->Name= $query->row($i)->Name;
			$temp->Email = $query->row($i)->Email;
			array_push($result, $temp);
		}
		//print_r($result);
		return $result;
	}
	function contactForm($form_data)
	{
		$email='';
		$query = $this->getAdmin();
		foreach ($query as $row)
		{
		   $email .= $row->email.',';
		}

		$config['protocol'] = 'smtp';
	   	$config['smtp_host'] = 'ssl://bigcorn.qwords.net';
	    $config['smtp_port'] = '465';
	    $config['smtp_user'] = 'fs@ferware.com'; // itu pake smtp gmail jadi gw kasi email gmail gtu. 
	    $config['smtp_pass'] = 'ferware!!!';
	    // $config['smtp_host'] = 'ssl://smtp.gmail.com';
	    // $config['smtp_port'] = '465';
	    // $config['smtp_user'] = '54vapedummy@gmail.com'; // itu pake smtp gmail jadi gw kasi email gmail gtu. 
	    // $config['smtp_pass'] = 'adminnyavape';
	    $config['mailtype'] = 'html';
	    $config['charset'] = 'iso-8859-1';
	    $config['wordwrap'] = TRUE;
	    $config['newline'] = "\r\n";
		$this->email->initialize($config);
		$this->email->clear(TRUE);

		$this->email->from($form_data['email'], $form_data['name']); // jadi nama pengirim itu ganti jadi yang di sana.
		$this->email->to($email); 
		/*$this->email->cc('ferico55@gmail.com'); 
		$this->email->bcc('anwijaya@binus.edu'); */

		$this->email->subject($form_data['subject']);
		$this->email->message($form_data['message'].'<br><br>'.$form_data['phone_number']);


		return $this->email->send();
	}
	function confirmPayment($data){
		$email='';
		$query = $this->getAdmin();
		foreach ($query as $row)
		{
		   $email .= $row->Email.',';
		}

		$queryString = "SELECT b.Name,b.Username,a.Total
						FROM trorder a
						JOIN msuser b ON a.UserID = b.UserID
						WHERE a.OrderID = ? AND a.AuditedActivity <> 'D' AND a.AuditedActivity <> 'D'";
		$query = $this->db->query($queryString, array($data['orderID']));


		$config['protocol'] = 'smtp';
	    $config['smtp_host'] = 'ssl://bigcorn.qwords.net';
	    $config['smtp_port'] = '465';
	    $config['smtp_user'] = 'fs@ferware.com'; // itu pake smtp gmail jadi gw kasi email gmail gtu. 
	    $config['smtp_pass'] = 'ferware!!!';
	    // $config['smtp_host'] = 'ssl://smtp.gmail.com';
	    // $config['smtp_port'] = '465';
	    // $config['smtp_user'] = '54vapedummy@gmail.com'; // itu pake smtp gmail jadi gw kasi email gmail gtu. 
	    // $config['smtp_pass'] = 'adminnyavape';
	    $config['mailtype'] = 'html';
	    $config['charset'] = 'iso-8859-1';
	    $config['wordwrap'] = TRUE;
	    $config['newline'] = "\r\n";
		$this->email->initialize($config);
		$this->email->clear(TRUE);

		$this->email->from('', $query->row(0)->Name); // jadi nama pengirim itu ganti jadi yang di sana.
		$this->email->to($email); 
		/*print_r($email);
		$this->email->cc('ferico55@gmail.com','rafanwij@gmail.com'); */
		//$this->email->bcc('anwijaya@binus.edu'); */

		$this->email->subject('Payment Confirmation');
		$this->email->message('Dear Admin,<br><br>
			Ada confirmation pembyaran dengan keterangan:<br>
			Username : '.$query->row(0)->Username.
			'<br>Name : '.$query->row(0)->Name.
			'<br>Total yang dibayarkan : '.$query->row(0)->Total.
			'<br>Tanggal pembayaran : '.$data['transferDate'].
			'<br>Bank : '.$data['bankName'].
			'<br>Nomor Rekening : '.$data['accountNumber'].
			'<br><br>Silahkan login dan mengkonfirmasi pembayaran.');

		return $this->email->send();
	}

	function send_email_CheckOut($email_to,$item,$data, $TrackingID){
		$config['protocol'] = 'smtp';
	  	$config['smtp_host'] = 'ssl://bigcorn.qwords.net';
	    $config['smtp_port'] = '465';
	    $config['smtp_user'] = 'fs@ferware.com'; // itu pake smtp gmail jadi gw kasi email gmail gtu. 
	    $config['smtp_pass'] = 'ferware!!!';
	    // $config['smtp_host'] = 'ssl://smtp.gmail.com';
	    // $config['smtp_port'] = '465';
	    // $config['smtp_user'] = '54vapedummy@gmail.com'; // itu pake smtp gmail jadi gw kasi email gmail gtu. 
	    // $config['smtp_pass'] = 'adminnyavape';
	    $config['mailtype'] = 'html';
	    $config['charset'] = 'iso-8859-1';
	    $config['wordwrap'] = TRUE;
	    $config['newline'] = "\r\n";
		$this->email->initialize($config);
		$this->email->clear(TRUE);

		$form_data['email_from'] = "54vapedummy@gmail.com";
		$form_data['name'] = "Vape";// jadi nama pengirim itu ganti jadi yang di sana.
		$form_data['subject'] = "Checkout";
		$form_data['message']='<b>Order Details</b><br> 
									<table style="border-collapse: separate;border-spacing: 15px 15px;" border="0">
									<tr style="font-size:12px;">
										<th>PRODUCT</th>
					  					<th>QTY</th>
										<th>TOTAL</th>
									</tr>';
		foreach ($item as $itemorder){
					$form_data['message'] = $form_data['message']."<tr><td>".$itemorder['name']."</td><td>".$itemorder['qty']."</td><td>"."Rp ".$this->cart->format_number($itemorder['price']*$itemorder['qty'])."</td>";
		}
		$form_data['message'] = $form_data['message']."<tr><td colspan='2'>Total</td><td>Rp ".$this->cart->format_number($this->cart->total())."</td></tr></table>";

		$form_data['message'] = $form_data['message']."<br><b>Customer Contact</b><br>";
		$form_data['message'] = $form_data['message'].$data['RecipientName']."<br>";
		$form_data['message'] = $form_data['message'].$data['Email']."<br>";
		$form_data['message'] = $form_data['message'].$data['PhoneNumber']."<br>";

		
		
		$form_data['message'] = $form_data['message']."<br><b>Billing Address</b><br>";
		$form_data['message'] = $form_data['message'].$data['address']."<br>";

		$form_data['message'] = $form_data['message']."<br><b>Shipping Cost</b><br>";
		$form_data['message'] = $form_data['message']."Rp ".$this->cart->format_number($data['ShippingCost'])."<br>";

		$form_data['email_to'] = $email_to;

		
		$this->email->from('no-reply@54vape.com', '(No-Reply)Customer Service 54 Vape'); // jadi nama pengirim itu ganti jadi yang di sana.
		$this->email->to($form_data['email_to']); 
		/*$this->email->cc('ferico55@gmail.com'); 
		$this->email->bcc('anwijaya@binus.edu'); */

		$this->email->subject($form_data['subject']);
		$this->email->message($form_data['message']);

		$myfile = fopen("invoice/".$TrackingID.".pdf", "w+");

		fwrite($myfile, stream_get_contents(fopen(base_url()."CheckOut/invoice/".$TrackingID,"r")));
		fclose($myfile);

		$this->email->attach(base_url()."invoice/".$TrackingID.".pdf");

		return $this->email->send();
	}
}