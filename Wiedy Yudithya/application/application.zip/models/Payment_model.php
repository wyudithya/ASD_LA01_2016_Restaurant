<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Payment_model extends CI_Model
{
	function __construct() 
	{
		parent::__construct();
	}

	function removeFromNotification($id)
	{
		$queryString = "UPDATE trnotification SET IsRead = 1, AuditedUser = ?, AuditedTime = CURRENT_TIMESTAMP, AuditedActivity = 'U' WHERE ReferenceID = ?";
		$query = $this->db->query($queryString,array($this->session->userdata('userID'),$id));
	}

	function getPaymentByID($id)
	{
		$queryString = "SELECT a.OrderID, a.BankName, a.AccountNumber, a.AccountName, a.TransferDate, b.Total, c.BankName AS DestinationBank, c.TransferDestinationID, d.Name, d.UserID FROM mspayment a JOIN trorder b ON a.OrderID = b.OrderID JOIN mstransferdestination c ON a.TransferDestinationID = c.TransferDestinationID JOIN msuser d ON b.UserID = d.UserID WHERE a.AuditedActivity <> 'D' AND a.PaymentID = ?";
		$query = $this->db->query($queryString,array($id));
		$i=0;
		$temp = new Temp();
		$temp->paymentID = $id;
		$temp->orderID = $query->row($i)->OrderID;
		$temp->bankName = $query->row($i)->BankName;
		$temp->accountNumber = $query->row($i)->AccountNumber;
		$temp->accountHolder = $query->row($i)->AccountName;
		$temp->transferDate = $this->getTimeString($query->row($i)->TransferDate);
		$temp->total = $query->row($i)->Total;
		$temp->destinationBank = $query->row($i)->DestinationBank;
		$temp->destinationID = $query->row($i)->TransferDestinationID;
		$temp->name = $query->row($i)->Name;
		$temp->userID = $query->row($i)->UserID;
		return $temp;
	}

	function process($id)
	{
		$queryString = "UPDATE mspayment SET IsProcessed = '1', AuditedActivity='U', AuditedTime=CURRENT_TIMESTAMP, AuditedUser=? WHERE PaymentID = ?";
		$this->db->query($queryString,array($this->session->userdata('userID'),$id));
		$queryString = "UPDATE trorder a JOIN mspayment b ON a.OrderID = b.OrderID SET a.OrderStatusID =3, a.AuditedActivity='U', a.AuditedTime=CURRENT_TIMESTAMP, a.AuditedUser=? WHERE b.PaymentID = ?";
		$this->db->query($queryString,array($this->session->userdata('userID'),$id));
	}

	function confirmPayment($id, $data)
	{
		$queryString = "INSERT INTO mspayment VALUES(?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 'I', ?, ?, '0')";
		$this->db->query($queryString,array($id, $data['orderID'], $data['bankName'],$data['accountNumber'],$data['transferDestination'],$this->session->userdata('userID'),$data['transferDate'],$data['accountHolder']));

		$notificationID = "NC".substr($data['bankName'],0,1).date('Ymdhis').substr(microtime(), 2,3);
		$queryString = "INSERT INTO trnotification VALUES(?,2,?,'0',CURRENT_TIMESTAMP, ?, CURRENT_TIMESTAMP, 'I')";
		$this->db->query($queryString,array($notificationID, $id, $this->session->userdata('userID')));

		$queryString = "UPDATE trorder SET OrderStatusID = 2, AuditedUser = ?, AuditedTime = CURRENT_TIMESTAMP, AuditedActivity = 'U' WHERE OrderID = ?";
		$this->db->query($queryString, array($this->session->userdata('userID'),$data['orderID']));
	}

	function getTimeString($t)
	{
		$t = strtotime($t);
		$ret = "";
		{
			$ret = date('d-M-Y',$t);
		}
		return $ret;
	}
}