<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class ContactForm_model extends CI_Model {
	function __construct() 
	{
		parent::__construct();
	}
	
	function removeFromNotification($id)
	{
		$queryString = "UPDATE trnotification SET IsRead = 1, AuditedUser = ?, AuditedTime = CURRENT_TIMESTAMP, AuditedActivity = 'U' WHERE ReferenceID = ?";
		$query = $this->db->query($queryString,array($this->session->userdata('userID'),$id));
	}

	function getAllContact()
	{
		$result = array();
		$queryString = "SELECT a.ContactID,Name,Email, PhoneNumber ,Message, a.Time, IsRead FROM mscontact a JOIN trnotification b ON a.ContactID = b.ReferenceID WHERE a.AuditedActivity <> 'D'";
		$query = $this->db->query($queryString);
		
		for($i=0;$i<$query->num_rows();$i++)
		{ 
				
				$temp = new Temp();
				$temp->ContactID = $query->row($i)->ContactID;
				$temp->Name = $query->row($i)->Name;
				$temp->Email = $query->row($i)->Email;
				$temp->PhoneNumber = $query->row($i)->PhoneNumber;
				//modified by FS 15 Des
				$temp->IsRead = $query->row($i)->IsRead;
				$arr = explode(" ", $query->row($i)->Message);
				$Message = "";
				$charCount = 0;
				$temp->Time = $this->getTimeString($query->row($i)->Time);
				if(strlen($query->row($i)->Message) > 70)
				{	
					$arr = "";
					$arr = explode(" ", $query->row($i)->Message);
					$Message = "";
					
					for($j = 0 ; $j < 10 ; $j++)
					{
						$Message = $Message . " ". $arr[$j];
						$charCount += strlen($arr[$i]);
						if($charCount>70)
							break;
					}
					$temp->Message = $Message . "...";
				}else
				{
					$temp->Message = $query->row($i)->Message;
				}
				array_push($result, $temp);			
		}
		return $result;
	}


	function getContactByID($id)
	{
		$temp = new Temp();
		$queryString = "SELECT ContactID,Name,Email, UserID, PhoneNumber ,Message, Time FROM mscontact WHERE AuditedActivity <> 'D' AND ContactID = ?";
		$query = $this->db->query($queryString,array($id));
		$i = 0;
		$temp->ContactID = $query->row($i)->ContactID;
		$temp->Name = $query->row($i)->Name;
		$temp->Email = $query->row($i)->Email;
		$temp->PhoneNumber = $query->row($i)->PhoneNumber;
		$temp->Message = $query->row($i)->Message;
		$temp->UserID = $query->row($i)->UserID;
		$temp->Time = $this->getTimeString($query->row($i)->Time);
		return $temp;
	}
		function deleteContactByID($id){
			$queryString = "UPDATE mscontact  SET AuditedActivity = 'D', AuditedUser = ?, AuditedTime = CURRENT_TIMESTAMP where ContactID = ? ";
			$query = $this->db->query($queryString,array($this->session->userdata('userID'),$id));
			redirect('BackEnd/ContactForms','refresh');
						
	}
	function getTimeString($t)
	{
		$t = strtotime($t);
		$ret = "";
		if(date('z')>date('z',$t))
		{
			$ret = date('d-M-Y',$t);
		}
		else
		{
			$ret = date('H:i',$t);
		}
		return $ret;
	}

}

/* End of file ContactForm_model.php */
/* Location: ./application/models/ContactForm_model.php */