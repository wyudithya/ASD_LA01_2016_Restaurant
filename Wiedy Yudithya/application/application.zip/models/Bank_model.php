<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Bank_model extends CI_Model {
	function __construct() 
	{
		parent::__construct();
	}

	function getBanks()
	{
		$result = array();
		$queryString = "SELECT * FROM mstransferdestination WHERE AuditedActivity <> 'D'";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->bankID = $query->row($i)->TransferDestinationID;
			$temp->name = $query->row($i)->BankName;
			$temp->accountNumber = $query->row($i)->AccountNumber;
			$temp->holderName = $query->row($i)->AccountName;
			array_push($result, $temp);
		}
		return $result;
	}

	function getBankByID($id)
	{
		$queryString = "SELECT * FROM mstransferdestination WHERE TransferDestinationID = ?";
		$query = $this->db->query($queryString,array($id));
		$temp = new stdClass();
		$temp->bankID = $query->row(0)->TransferDestinationID;
		$temp->name = $query->row(0)->BankName;
		$temp->accountNumber = $query->row(0)->AccountNumber;
		$temp->holderName = $query->row(0)->AccountName;
		return $temp;
	}

	function add($data)
	{
		$queryString = "INSERT INTO mstransferdestination VALUES(NULL, ?, ?, ?, ?, CURRENT_TIMESTAMP, 'I')";
		$this->db->query($queryString,array($data["bankName"],$data["accountNumber"],$data["holderName"],$this->session->userdata('userID')));
	}

	function update($data,$id)
	{
		//die($this->session->userdata('userID'));
		$queryString = "UPDATE mstransferdestination SET BankName = ?, AccountNumber = ?, AccountName = ?, AuditedUser = ?, AuditedTime = CURRENT_TIMESTAMP, AuditedActivity='U'";
		$this->db->query($queryString, array($data["bankName"],$data["accountNumber"],$data["holderName"],$this->session->userdata('userID')));
	}

	function delete($id)
	{
		$queryString = "UPDATE mstransferdestination SET AuditedActivity = 'D', AuditedTime = CURRENT_TIMESTAMP, AuditedUser=? WHERE TransferDestinationID = ?";
		$this->db->query($queryString,array($this->session->userdata('userID'),$id));
	}
}