<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard_model extends CI_Model
{
	function __construct() 
	{
		parent::__construct();
	}

	function getMostSoldProduct()
	{
		$result = array();
		$queryString = "SELECT ProductID, ProductName, TransactionCount FROM msproduct WHERE AuditedActivity <> 'D' ORDER BY TransactionCount DESC LIMIT 20";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new Temp();
			$temp->productID = $query->row($i)->ProductID;
			$temp->productName = $query->row($i)->ProductName;
			$temp->transactionCount = $query->row($i)->TransactionCount;
			array_push($result, $temp);
		}
		return $result;
	}

	function getWeeklySales($span)
	{
		$result = array();
		$d = date('Y-m-d 00:00:00',strtotime('-'.$span.' week'));
		$queryString = "SELECT SUM(c.Price*b.Qty) AS Sales, a.ReceivedDate FROM trorder a JOIN trorderdetail b ON a.OrderID = b.OrderID JOIN msproduct c ON c.ProductID = b.ProductID WHERE a.ReceivedDate > ? AND a.OrderStatusID = (SELECT OrderStatusID FROM ltorderstatus ORDER BY OrderStatusID DESC LIMIT 1) GROUP BY ReceivedDate";
		$query = $this->db->query($queryString,array($d));
		$tempWeek = -1;
		for($i=0;$i<$query->num_rows();$i++)
		{
			$weekNumber = date('W',strtotime($query->row($i)->ReceivedDate));
			if($weekNumber!=$tempWeek)
			{
				$tempWeek = $weekNumber;
				$temp = new Temp();
				$temp->weekNumber = $weekNumber;
				$temp->sales = $query->row($i)->Sales;
				array_push($result, $temp);
			}
			else
			{
				$temp->sales+=$query->row($i)->Sales;
			}
		}
		return $result;
	}

	function getTopUser()
	{
		$result = array();
		$queryString = "SELECT b.UserID, b.Name FROM trorder a JOIN msuser b ON a.UserID = b.UserID ORDER BY UserID";
		$query = $this->db->query($queryString);

		$tempID = "";
		for($i=0;$i<$query->num_rows();$i++)
		{
			if($tempID!=$query->row($i)->UserID)
			{
				$tempID = $query->row($i)->UserID;
				$temp = new Temp();
				$temp->userID = $query->row($i)->UserID;
				$temp->name = $query->row($i)->Name;
				$temp->count = 1;
				array_push($result, $temp);
			}
			else
				$temp->count++;
		}
		return $result;
	}
}