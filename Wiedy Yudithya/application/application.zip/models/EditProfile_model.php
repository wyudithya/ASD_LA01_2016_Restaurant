<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class EditProfile_model extends CI_Model {

	function __construct()
	{
		parent::__construct();
	}
	function GetData($id){
		$queryString = "SELECT * FROM msuser WHERE UserID = ?";
		$query = $this->db->query($queryString, array($id));
		return $query;
	}
	function SaveForm($form_data)
	{
		$data = array (
			'username' => $form_data['username'],
			'userType' => "Customer",
			'userTypeID' => 3
		);
		$this->session->set_userdata($data);
		$queryString = "UPDATE msuser SET Name = ?, Email=?,`PhoneNumber`=?,`DOB`=?,`Address`=?,`AuditedUser`= ?,`AuditedTime`= CURRENT_TIMESTAMP,`AuditedActivity`= 'U' WHERE Username = ?";
		$query = $this->db->query($queryString,array($form_data['name'],$form_data['email'],$form_data['phone_number'],$form_data['date_of_birth'],$form_data['address'], $this->session->userdata('userID'),$form_data['username']));
		return $query;
	}
}
?>