<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contactus_model extends CI_Model {

	function __construct()
	{
		parent::__construct();
	}
	
	function SaveForm($form_data)
	{
		$queryString = "INSERT INTO mscontact(ContactID,UserID,Name,Email,PhoneNumber,Message,Time,AuditedUser,AuditedTime,AuditedActivity) Values(?,'',?,?,?,?,now(),'',CURRENT_TIMESTAMP,'I')";
		$query = $this->db->query($queryString,array($form_data['contactid'],$form_data['name'],$form_data['email'],$form_data['phone_number'],$form_data['message']));
		return $query;
	}
	function NotifInsert($notif_data){
		$queryString = "INSERT INTO trnotification(NotificationID,NotificationTypeID,ReferenceID,isRead,Time,AuditedUser,AuditedTime,AuditedActivity) Values(?,?,?,0,now(),'',CURRENT_TIMESTAMP,'I')";
		$query = $this->db->query($queryString,array($notif_data['notifid'],$notif_data['notiftypeid'],$notif_data['referenceid']));
		return $query;
	}
}
?>