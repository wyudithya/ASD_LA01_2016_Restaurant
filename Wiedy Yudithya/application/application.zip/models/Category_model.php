<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category_model extends CI_Model
{
	function __construct() 
	{
		parent::__construct();
	}

	function getParentCategoryP()
	{
		$result = array();
		$queryString = "SELECT a.CategoryID, CategoryName, COUNT(ProductID) as ProductCount FROM mscategory a LEFT JOIN msproduct b ON a.CategoryID = b.CategoryID WHERE a.AuditedActivity <> 'D' AND IsSubCategory = '0' AND (b.AuditedActivity IS NULL OR b.AuditedActivity <> 'D') GROUP BY a.CategoryID, CategoryName";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->categoryID = $query->row($i)->CategoryID;
			$temp->categoryName = $query->row($i)->CategoryName;
			$temp->productCount = $query->row($i)->ProductCount;
			array_push($result, $temp);
		}
		return $result;
	}
	function getCategory()
	{
		$result =array();
		$queryString = "SELECT a.CategoryID, CategoryName, a.ParentCategoryID, COUNT(ProductID) as ProductCount FROM mscategory a LEFT JOIN msproduct b ON a.CategoryID = b.CategoryID WHERE a.AuditedActivity <> 'D' AND IsSubCategory = '1' AND (b.AuditedActivity IS NULL OR b.AuditedActivity <> 'D') GROUP BY a.CategoryID, CategoryName, a.ParentCategoryID";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->categoryID = $query->row($i)->CategoryID;
			$temp->categoryName = $query->row($i)->CategoryName;
			$temp->productCount = $query->row($i)->ProductCount;
			$temp->parentID = $query->row($i)->ParentCategoryID;
			array_push($result, $temp);
		}
		return $result;
	}
	function getCategoryHeader()
	{
		$result=array();
		$queryString="SELECT CategoryID,CategoryName FROM mscategory WHERE AuditedActivity<>'D'";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->categoryID = $query->row($i)->CategoryID;
			$temp->categoryName = $query->row($i)->CategoryName;
			array_push($result, $temp);
		}
		return $result;
	}
	function deleteCategory($id)
	{
		$queryString = "UPDATE mscategory SET AuditedActivity ='D', ParentCategoryID='0', AuditedTime = CURRENT_TIMESTAMP, AuditedUser = ? WHERE CategoryID = ?";
		$this->db->query($queryString,array($this->session->userdata('userID'),$id));
	}

	function getCategoryName($id)
	{
		$queryString = "SELECT CategoryName from mscategory WHERE CategoryID = ? AND AuditedActivity <> 'D'";
		$query = $this->db->query($queryString,array($id));
		if($query->num_rows()>0)
			return $query->row(0)->CategoryName;
		else
			return "";
	}

	function getParentCategory()
	{
		$queryString = "SELECT CategoryName, CategoryID FROM mscategory WHERE IsSubCategory='0' AND AuditedActivity<>'D'";
		$query = $this->db->query($queryString);
		$result = array();
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new Temp();
			$temp->categoryName = $query->row($i)->CategoryName;
			$temp->categoryID = $query->row($i)->CategoryID;
			array_push($result, $temp);
		}
		return $result;
	}

	function updateCategory($name,$isSubCategory,$parentID,$id)
	{
		if($isSubCategory=="on")
		{
			$queryString = "UPDATE mscategory SET CategoryName = ?, ParentCategoryID = ?, IsSubCategory = '1', AuditedActivity = 'U', AuditedTime =CURRENT_TIMESTAMP, AuditedUser=? WHERE CategoryID = ?";
			$query = $this->db->query($queryString,array($name,$parentID,$this->session->userdata('userID'),$id));
		}
		else
		{
			$queryString = "UPDATE mscategory SET CategoryName = ?, ParentCategoryID = '0', IsSubCategory = '0', AuditedActivity = 'U', AuditedTime =CURRENT_TIMESTAMP, AuditedUser=? WHERE CategoryID = ?";
			$query = $this->db->query($queryString,array($name,$this->session->userdata('userID'),$id));
		}
	}

	function insertCategory($name,$isSubCategory,$parentID)
	{
		if($isSubCategory=="on")
		{
			$isSubCategory = "1";
			$queryString = "INSERT INTO mscategory VALUES(NULL, ?, '1',?,?,CURRENT_TIMESTAMP,'I')";
			$this->db->query($queryString,array($parentID,$name,$this->session->userdata('userID')));
		}
		else
		{
			$isSubCategory = "0";
			$queryString = "INSERT INTO mscategory VALUES(NULL,'0','0',?,?,CURRENT_TIMESTAMP,'I')";
			$this->db->query($queryString,array($name,$this->session->userdata('userID')));
		}		
	}

	function getAllCategory()
	{
		$result = array();
		$queryString = "SELECT CategoryName, CategoryID, IsSubCategory FROM mscategory WHERE AuditedActivity <> 'D'";
		$query = $this->db->query($queryString);
		for($i=0;$i<$query->num_rows();$i++)
		{
			$temp = new stdClass();
			$temp->categoryID = $query->row($i)->CategoryID;
			$temp->categoryName = $query->row($i)->CategoryName;
			$temp->isSubCategory = ($query->row($i)->IsSubCategory=='1')?true:false;
			array_push($result, $temp);
		}
		return $result;
	}
	function getCategoryWithDescendant($id)
	{
		$result = array();
		$queryString = "SELECT a.CategoryID, CategoryName, IsSubCategory, ProductName, Price, b.Discount, b.ProductID, b.Photo, b.IsFeatured FROM mscategory a LEFT JOIN msproduct b ON a.CategoryID = b.CategoryID WHERE (a.CategoryID = ? OR (ParentCategoryID = ? AND IsSubCategory = '1')) AND a.AuditedActivity<>'D' AND (b.AuditedActivity IS NULL OR b.AuditedActivity <> 'D') ORDER BY IsSubCategory ASC, IsFeatured DESC";//along with the products
		$query = $this->db->query($queryString,array($id,$id));
		$tempID = "";
		for($i=0;$i<$query->num_rows();$i++)
		{
			if($tempID!=$query->row($i)->CategoryID)
			{
				$tempID = $query->row($i)->CategoryID;
				$temp = new stdClass();
				$temp->categoryID = $query->row($i)->CategoryID;
				$temp->categoryName = $query->row($i)->CategoryName;
				$temp->isSubCategory = ($query->row($i)->IsSubCategory=='1')?true:false;
				$temp->products = array();
				array_push($result, $temp);
			}
			if($query->row($i)->ProductID)
			{
				//modified by FS 5 Des
				$product = new stdClass();
				$product->productID = $query->row($i)->ProductID;
				$product->productName = $query->row($i)->ProductName;
				$product->discount = $query->row($i)->Discount;
				$product->price = $query->row($i)->Price;
				$arr = explode(";", $query->row($i)->Photo);
				$product->photo = $arr[0];
				$product->isFeatured = ($query->row($i)->IsFeatured=='1')?true:false;
				array_push($temp->products, $product);
			}
		}
		//nanti urutannya diubah, yang parent paling atas!
		return $result;
	}

	function loadCategories()
	{
		$result =array();
		$queryString = "SELECT a.CategoryID, a.CategoryName, a.ChildName, a.ChildID, COUNT(ProductID) AS ProductCount FROM (SELECT b.CategoryID, b.CategoryName, c.CategoryName AS ChildName, c.CategoryID AS ChildID FROM mscategory b LEFT JOIN mscategory c ON b.CategoryID = c.ParentCategoryID WHERE b.AuditedActivity<>'D' AND b.IsSubCategory='0') AS a LEFT JOIN msproduct d ON d.CategoryID = a.CategoryID GROUP BY a.CategoryID, a.CategoryName, a.ChildName, a.ChildID";
		$query = $this->db->query($queryString);
		if($query->num_rows()==0)
			return $result;
		$tempID = 0;
		$cat;
		for($i=0;$i<$query->num_rows();$i++)
		{
			if($tempID!=$query->row($i)->CategoryID)
			{
				$cat = new stdClass();
				$cat->categoryID=$query->row($i)->CategoryID;
				$cat->categoryName = $query->row($i)->CategoryName;
				$cat->childCategory = array();
				$tempID = $cat->categoryID;
				if($query->row($i)->ChildID==NULL)
					$cat->productCount = $query->row($i)->ProductCount;
				else
				{
					$temp = new stdClass();
					$temp->categoryID=$query->row($i)->ChildID;
					$temp->categoryName = $query->row($i)->ChildName;
					$temp->productCount = $query->row($i)->ProductCount;
					array_push($cat->childCategory, $temp);
				}
				array_push($result, $cat);
			}
			else
			{
				$temp = new stdClass();
				$temp->categoryID=$query->row($i)->ChildID;
				$temp->categoryName = $query->row($i)->ChildName;
				$temp->productCount = $query->row($i)->ProductCount;
				array_push($cat->childCategory, $temp);
			}
		}
		return $result;
	}
}