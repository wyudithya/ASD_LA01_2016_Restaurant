<!-- Morris Charts JavaScript -->
    <script src="<?php echo base_url()?>assets/bower_components/morrisjs/morris.min.js"></script>