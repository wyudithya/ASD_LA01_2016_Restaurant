<?php require("template/header.php"); ?>

<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"><?php if(isset($header)) echo "User - ".$header; else echo "All User"; ?></h1>
        </div>
    </div>
	<div class="row">
		<div class="col-md-12">
			<table class="table table-bordered table-hover table-striped tablesorter">
			<thead>
			<tr>
				<th>No</th>
				<th>Username</th>
				<th>Name</th>
				<th>Address</th>
				<th>DOB</th>
				<th>UserType</th>
			</tr>
			</thead>
			<tbody>
			<?php
			if(count($user) != 0 )
			{
				for($i=0;$i<count($user);$i++)
				{ ?>
					<tr onclick="document.location = '<?php echo base_url() ?>BackEnd/Users/detail/<?php echo $user[$i]->UserID ?>';" style="cursor:pointer">
						<td><?php echo ($i+1) ?></td>
						<td><?php echo $user[$i]->Username ?></td>
						<td><?php echo $user[$i]->Name ?></td>
						<td><?php echo $user[$i]->Address ?></td>
						<td><?php echo $user[$i]->DOB ?></td>
						<td><?php echo $user[$i]->UserType ?></td>

					</tr>
				<?php } 
			} else{ ?>
				<tr>
						<td colspan="6" style="text-align: center;">No Data Available</td>
					
					</tr>
					<?php
			}
			?>
			</tbody>
			</table>
		</div>
	</div>
</div>

<?php require("template/footer.php"); ?>
<script type="text/javascript">
	$(document).ready(function(){
    $(".tablesorter").tablesorter();
});
</script>