<style type="text/css">
	div.inline { display: inline-block; }
	.customNavigation{ float: right!important;margin: 3px;}
</style>
<div class="col-md-12 col-xs-12 xol-sm-12">
	<div id="content">
		<?php
		$isUsingHeader = false;
		if(!$categories[0]->isSubCategory&&count($categories)>0){ ?>
			<div class="col-md-12 col-xs-12 xol-sm-12 no-padding" style="margin-bottom:8px; margin-top:8px">
				<div id="whiteBlock">
					<h2><?php $isUsingHeader = true; echo $categories[0]->categoryName; ?></h2>
				</div>
			</div><br>
		<?php } ?>
		<?php for($i=0;$i<count($categories);$i++){ ?>
			<?php if($i==0&&$isUsingHeader) continue; ?>
			<div class="col-md-12 col-xs-12 xol-sm-12 no-padding" style="margin-bottom:8px; margin-top:8px">
				<div id="whiteBlock">
					<?php echo $categories[$i]->categoryName; ?>
				</div>
			</div>
			<br>
			<div class="col-md-12 col-xs-12 xol-sm-12 no-padding">
			<?php 
			$tempName = "";
			for($j=0;$j<count($categories[$i]->products);$j++){ 
				if($tempName==$categories[$i]->products[$j]->productName)
					continue;
				else
					$tempName = $categories[$i]->products[$j]->productName;
			?>
				<div class="col-xs-12 col-sm-6 col-md-3">
					<a href="<?php echo base_url('Home/detail_product'."/".$categories[$i]->products[$j]->productID);?>" style="color:black;text-decoration: none;">
						<div class="item" style="background-color:white; padding:1em;">
							<div class="product">
								<?php if(isset($categories[$i]->products[$j]->discount)&&$categories[$i]->products[$j]->discount>0){ ?>
								<div class="box-discount">
									<img src="<?php echo base_url() ?>assets/images/star.png" class="discount-star">
									<span class="dicount-text">
										<?php echo $categories[$i]->products[$j]->discount; ?>% OFF
									</span>
								</div>
								<?php } ?>
								<div class="box-product">
									<?php
										if(isset($categories[$i]->products[$j]->photo)){
									?>
										<img class="product-thumb img-responsive centered" src="<?php echo base_url().'assets/Products/thumb/'.$categories[$i]->products[$j]->photo?>" onError="this.onerror=null; this.src='<?php echo base_url(); ?>assets/images/notAvailable.jpg';"alt="..." >
									<?php } ?>
								</div>
								<h4>
									<?php 
										if(isset($categories[$i]->products[$j]->productName))
											echo $categories[$i]->products[$j]->productName;
										else
											echo '-';
									?>
								</h4>
								<div class="box-price">
									<?php 
										if(isset($categories[$i]->products[$j]->price)){
											echo "Rp. ";
											echo number_format($categories[$i]->products[$j]->price*(100-$categories[$i]->products[$j]->discount)/100, 0, ',', '.');
										}else{
											echo "Rp. ";
											echo '-';
										}
									?>
								</div>
							</div>
						</div>
					</a>
				</div>
			<?php } ?>
			</div>
		<?php } ?>
	</div>
</div>
<?php $this->load->view('FrontEnd/footer'); ?>
<style type="text/css">
@media screen and (max-width: 700px)
{
    .col-xs-12
    {
    	margin-top:1em;
    	margin-bottom: 1em;
    }
}
</style>
<script src="<?php echo base_url();?>assets/js/bootstrap-collapse.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap-transition.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap-tab.js"></script>