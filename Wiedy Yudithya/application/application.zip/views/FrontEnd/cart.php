<!DOCTYPE html>
<div class="col-md-12">
	<div id="content">
		<div class="col-xs-10 col-xs-offset-1 no-padding" style="margin-top:2em;">
			<div class="box white bottom" style="width:100%;">
				<div class="hidden-xs">
					<h2 class="title">My Cart</h2>
					<div class="top col-md-12 col-xs-12 no-padding" >		
						<div class="col-xs-12 no-padding">				
							<div class="col-md-6 col-xs-6 no-padding">
								<b><h4>Product</h4></b>
							</div>
							<div class="col-md-2 col-xs-2">
								<b><h4>Quantity</h4></b>
							</div>
							<div class="col-md-2 col-xs-2">
								<b><h4>Price</h4></b>
							</div>
							<div class="col-md-2 col-xs-2">
								<b><h4>Subtotal</h4></b>
							</div>
						</div>					
					</div>
					<div class="cart col-md-12 col-xs-12 no-padding">
						<div class="col-xs-12 top no-padding" style="line-height:8em;vertical-align:middle;">				
							<div class="col-md-6 col-xs-6 no-padding">
								<div class="no-padding right-padding">
									<div class="col-md-4 col-xs-4 product no-padding">
										<div class="box-product" style="max-height:8em;">
											
										</div>									
									</div>
									<div class="col-md-8 col-xs-8">									
										Orange Pen
									</div>
								</div>
							</div>
							<div class="col-md-2 col-xs-2">
								<div class="pink qty">
									1
								</div>
							</div>
							<div class="col-md-2 col-xs-2">
								Rp 200,000
							</div>
							<div class="col-md-2 col-xs-2">
								Rp 200,000
							</div>
						</div>		
						<!-- 2 -->
						<div class="col-xs-12 top no-padding" style="line-height:8em;vertical-align:middle;">				
							<div class="col-md-6 col-xs-6 no-padding">
								<div class="no-padding right-padding">
									<div class="col-md-4 col-xs-4 product no-padding">
										<div class="box-product" style="max-height:8em;">
											
										</div>									
									</div>
									<div class="col-md-8 col-xs-8">									
										Orange Pen
									</div>
								</div>
							</div>
							<div class="col-md-2 col-xs-2">
								<div class="pink qty">
									1
								</div>
							</div>
							<div class="col-md-2 col-xs-2">
								Rp 200,000
							</div>
							<div class="col-md-2 col-xs-2">
								Rp 200,000
							</div>
						</div>		
						<!-- 3 -->
						<div class="col-xs-12 top no-padding" style="line-height:8em;vertical-align:middle;">				
							<div class="col-md-6 col-xs-6 no-padding">
								<div class="no-padding right-padding">
									<div class="col-md-4 col-xs-4 product no-padding">
										<div class="box-product" style="max-height:8em;">
											
										</div>									
									</div>
									<div class="col-md-8 col-xs-8">									
										Orange Pen
									</div>
								</div>
							</div>
							<div class="col-md-2 col-xs-2">
								<div class="pink qty">
									1
								</div>
							</div>
							<div class="col-md-2 col-xs-2">
								Rp 200,000
							</div>
							<div class="col-md-2 col-xs-2">
								Rp 200,000
							</div>
						</div>	

					</div>
				</div>

				<!-- small -->
				<div class="visible-xs">
					<h2 class="title">My Cart</h2>
					<div class="top col-md-12 col-xs-12 no-padding" >		
						<div class="col-xs-12 no-padding">				
							<div class="col-xs-4 no-padding">
								<b><h4>Product</h4></b>
							</div>
							<div class="col-xs-2">
								<b><h4>Qty</h4></b>
							</div>
							<div class="col-xs-3">
								<b><h4>Price</h4></b>
							</div>
							<div class="col-xs-3">
								<b><h4>Subtotal</h4></b>
							</div>
						</div>					
					</div>
					<div class="cart col-xs-12 no-padding">
						<div class="col-xs-12 top no-padding" style="line-height:8em;vertical-align:middle;">				
							<div class="col-xs-4 no-padding">
								<div class="no-padding right-padding">
									<div class="col-xs-4 no-padding">							
										Orange pen
									</div>								
								</div>
							</div>
							<div class="col-xs-2">
								<div class="pink qty" style="padding-left:0;">
									1
								</div>
							</div>
							<div class="col-xs-3">
								Rp 200,000
							</div>
							<div class="col-xs-3">
								Rp 200,000
							</div>
						</div>		
						<!-- 2 -->
						<div class="col-xs-12 top no-padding" style="line-height:8em;vertical-align:middle;">				
							<div class="col-xs-4 no-padding">
								<div class="no-padding right-padding">
									<div class="col-xs-4 no-padding">							
										Orange Pen	
									</div>								
								</div>
							</div>
							<div class="col-xs-2">
								<div class="pink qty">
									1
								</div>
							</div>
							<div class="col-xs-3">
								Rp 200,000
							</div>
							<div class="col-xs-3">
								Rp 200,000
							</div>
						</div>
						<!-- 3 -->
						<div class="col-xs-12 top no-padding" style="line-height:8em;vertical-align:middle;">				
							<div class="col-xs-4 no-padding">
								<div class="no-padding right-padding">
									<div class="col-xs-4 no-padding">							
										Orange Pen	
									</div>								
								</div>
							</div>
							<div class="col-xs-2">
								<div class="pink qty">
									1
								</div>
							</div>
							<div class="col-xs-3">
								Rp 200,000
							</div>
							<div class="col-xs-3">
								Rp 200,000
							</div>
						</div>	
					</div>
				</div>

				<div class="col-md-offset-6 col-md-3 col-sm-offset-4 col-sm-3 link" style="width:10em;margin-top:1.5em;">
					<a href="#">
						Update
					</a>
				</div>
				<div class="col-md-12">
					<div class="col-md-12 col-sm-12 top">
						<h4 style="float:right;">Total : Rp 600,000</h4>
					</div>
					<div class="col-md-12">
						<a href="#"><div class="btn brown center" style="width:11em;margin-top:1.5em;float:right;display:block;">
							Proceed to Checkout
						</div></a>
					</div>
				</div>
			</div>
		</div>
		
	</div>
</div>
	<?php $this->load->view('FrontEnd/footer'); ?>
