<div class="col-md-12">
	<div id="content">
		<div id="whiteBlock">
			CHECKOUT
		</div>
		<div id="whiteBlock" style="margin:20px 0px;">
			BILLING ADDRESS
		</div>
		<div id="fontStyle" class="" style="color:white;">
			<?php
				$attributes = array();
				echo form_open('CheckOut/placeorder', $attributes); ?>

				  <!--<div class="form-group col-md-5" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
				 		<label for="firstname">First Name<span class="required">*</span></label>
				 	</div>
				 	<div class="col-md-12" style="padding:0">
				        <input class="form-control" id="firstname" type="text" name="firstname" maxlength="100" value="<?php echo set_value('firstname'); ?>"  />
				        <?php echo form_error('firstname'); ?>
				    </div>
				  </div>

				  <div class="form-group col-md-5 col-md-offset-2" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
				 		<label for="lastname">Last Name<span class="required">*</span></label>
				 	</div>
				 	<div class="col-md-12" style="padding:0">
				        <input class="form-control" id="lastname" type="text" name="lastname" maxlength="100" value="<?php echo set_value('lastname'); ?>"  />
				        <?php echo form_error('lastname'); ?>
				    </div>
				  </div>
					-->
				  <div class="form-group col-md-12" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
				 		<label for="recipientname">Recipient Name<span class="required">*</span></label>
				 	</div>
				 	<div class="col-md-12" style="padding:0">
				        <input class="form-control" id="recipientname" type="text" name="recipientname" maxlength="100" value="<?php echo $user->Name ?>"  />
				        <?php echo form_error('recipientname'); ?>
				    </div>
				  </div>
				  <!--
				  <div class="form-group col-md-12" style="padding:0">
				  	<div class="col-md-12 " style="padding:0">
					    <label for="companyname">Company Name</label>
					 </div>
					 <div class="col-md-12" style="padding:0;">
				        <input class="form-control" id="companyname" type="text" name="companyname" maxlength="100" value="<?php echo set_value('companyname'); ?>"  />
				       	<?php echo form_error('companyname'); ?>
				    </div>
				  </div>
					-->
				  <div class="form-group col-md-5" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
					    <label for="email">Email <span class="required">*</span></label>
					 </div>
					 <div class="col-md-12" style="padding:0;">
				        <input class="form-control" id="email" type="text" name="email" maxlength="100" value="<?php echo $user->Email; ?>"  />
				        <?php echo form_error('email'); ?>
				    </div>
				  </div>

				  <div class="form-group col-md-5 col-md-offset-2" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
					   <label for="phone_number">Phone Number <span class="required">*</span></label>
					</div>
					<div class="col-md-12" style="padding:0;">
				        <input class="form-control" id="phone_number" type="text" name="phone_number" maxlength="100" value="<?php echo $user->PhoneNumber; ?>"  />
				        <?php echo form_error('phone_number'); ?>
				    </div>
				  </div>

				  <div class="form-group col-md-12" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
					   <label for="Notes">Notes</label>
					</div>
					<div class="col-md-12" style="padding:0">
						<?php echo form_textarea( array( 'name' => 'Notes', 'rows' => '5', 'cols' => '80', 'value' => set_value('Notes') ) )?>
						<?php echo form_error('Notes'); ?>
					</div>
				  </div>

				  <div class="form-group col-md-12" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
					   <label for="address">Address <span class="required">*</span></label>
					</div>
					<div class="col-md-12" style="padding:0">
						<?php echo form_textarea( array( 'name' => 'address', 'rows' => '5', 'cols' => '80', 'value' => $user->Address ) )?>
						<?php echo form_error('address'); ?>
					</div>
				  </div>

				  <div class="form-group col-md-5" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
					    <label for="province">Province<span class="required">*</span></label>
					</div>
					<div class="col-md-12" style="padding:0">
						<select class="form-control" id="province" onchange="changeProvince()" name="province">
							 <option selected disabled>Choose Province</option>
				        </select>
				        <?php echo form_error('province'); ?>
				     </div>
				  </div>

				  <div class="form-group col-md-5 col-md-offset-2" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
					    <label for="city">City<span class="required">*</span></label>
					</div>
					<div class="col-md-12" style="padding:0">
						<select onchange="changeCity()" class="form-control" id="city" name="city">
							 <option selected disabled>Choose City</option>
				        </select>
				        <?php echo form_error('city'); ?>
				     </div>
				  </div>

				   <div class="form-group col-md-5" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
					    <label for="service">Service Type<span class="required">*</span></label>
					</div>
					<div class="col-md-12" style="padding:0">
				        <select onchange="changeService()" class="form-control" id="service" name="service">
							 <option selected disabled>Choose Service</option>
				        </select>
				        <?php echo form_error('postcode'); ?>
				     </div>
				  </div>

				  <div class="form-group col-md-5 col-md-offset-2" style="padding:0">
				  	<div class="col-md-12" style="padding:0">
					    <label for="ongkosKirim">Courier Cost<span class="required">*</span></label>
					</div>
					<div class="col-md-12" style="padding:0">
				        <input class="form-control" disabled id="ongkosKirimDis" type="number" name="ongkosKirimDis" maxlength="100" value="<?php echo set_value('ongkosKirim'); ?>"  />
				        <input class="form-control" style="display:none" id="ongkosKirim" type="number" name="ongkosKirim" maxlength="100" value="<?php echo set_value('ongkosKirim'); ?>"  />
				        <?php echo form_error('ongkosKirim'); ?>
				     </div>
				  </div>

				<div class="col-md-12 no-padding">
					<div id="whiteBlock">
						Your Order
					</div>
				</div>
				<div class="col-md-12 no-padding">
					<table class="col-md-8 col-xs-12 no-padding" style="border-collapse: separate; padding-top:3em; padding-bottom:3em; " border="0">
						<tr style="font-size:20px;">
							<th>PRODUCT</th>
					  		<th>QTY</th>
					  		<th>DISCOUNT</th>
							<th>TOTAL</th>
						</tr>
						<?php $i = 1; ?>
						<?php foreach ($this->cart->contents() as $items): ?>
						<?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>
						<tr style="font-size:20px;">
		 					<td>
								<?php echo $items['name']; ?>
								<?php if ($this->cart->has_options($items['rowid']) == TRUE): ?>
								<p>
								<?php foreach ($this->cart->product_options($items['rowid']) as $option_name => $option_value): ?>
								<strong><?php echo $option_name; ?>:</strong> <?php echo $option_value; ?><br />
								<?php endforeach; ?>
								</p>
								<?php endif; ?>
		  					</td>
		  					<td style="color:#774c29;">x<?php echo $items['qty']; ?></td>
		  					<td style="color:#774c29;"><?php echo $items['discount']; ?>%</td>
		  					<td>
		  					Rp <?php echo $this->cart->format_number($items['price']*$items['qty']); ?>
		  					</td>
		  						<!--<?php if(isset($items['discount']) && $items['discount']!= 0){?>
		  						<strike>Rp <?php echo $this->cart->format_number($items['price']*$items['qty']); ?></strike><br>
		  						Rp <?php echo $this->cart->format_number($items['price']*$items['qty']*((100-$items['discount'])/100)); ?></td>
		  						<?php }else{ ?>

		  							Rp <?php echo $this->cart->format_number($items['price']*$items['qty']); ?>
		  						<?php }?>
		  						-->
						</tr>

						<?php $i++; ?>
						<?php endforeach; ?>

				</table>

				</div>
				<div class="col-md-12 no-padding" style="margin-top:20px;font-size:24px;">
				 	<div class="col-md-12 no-padding" style="font-size:16px;">DIRECT BANK TRANSFER</div>
				 	<div class="col-md-12 no-padding" style="font-size:14px;">You will be given the payment instructions on your email, Kindly note that no credit or debit card payment are possible.</div>
				 	
				</div>
				<div class="col-md-12 no-padding" style="margin-top:20px;font-size:24px;">

				  	<div class="col-md-3 col-md-offset-3 col-xs -offset-3 col-xs-3"><strong>Total</strong></div>
	 				<div class="col-md-3 col-xs-6"><strong id="totalCost">Rp<?php echo $this->cart->format_number($this->cart->total()); ?></strong></div>
			  		<?php echo form_submit('submit', 'Place Order','class="btn brown col-md-3 col-xs-3" id="btnSubmit"'); ?>
					<?php echo form_close(); ?>
				</div>

		</div>
	</div>
</div>
<style type="text/css">
	input[type="text"],[type="password"],[type="date"]{
		color :black;
	}
	label{
		text-align: left;
		float:left;
	}
	textarea{
		color :black;
		width:100%;
	}
</style>
<?php $this->load->view('FrontEnd/footer'); ?> 
<script type="text/javascript">
var province;
var city;
var service;
var cost = <?php $this->cart->total(); ?>;

$(document).ready(function()
{
	$("#service").attr('disabled','disabled');
	$("#province").attr('disabled','disabled');
	$("#btnSubmit").attr('disabled','disabled');
	$.ajax({
		url: "<?php echo base_url() ?>ongkir/province.php",
		type: "POST",
		data:
		{
			id : "55"
		},
		success: function(result){
			$("#province").removeAttr('disabled')
			result = JSON.parse(result);
			result = JSON.parse(result);
			province = result.rajaongkir.results;
			for(var i=0;i<province.length;i++)
			{
				$('#province').append($('<option>', {
				    value: province[i].province,
				    text: province[i].province
				}));
			}
		}
	});

	$("#city").attr('disabled','disabled');
});
function changeProvince()
{
	$("#btnSubmit").attr('disabled','disabled');
	$("#city").attr('disabled','disabled');
	$("#totalCost").html("Rp"+cost.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,'));
	$("#city option").each(function() {
	    $(this).remove();
	});
	$("#service option").each(function() {
	    $(this).remove();
	});
	$("#ongkosKirim").val(0);
	var id;

	for(var i=0;i<province.length;i++)
	{
		if(province[i].province==$("#province").val())
			id = province[i].province_id;
	}

	$.ajax({
		url: "<?php echo base_url() ?>ongkir/city.php",
		type: "POST",
		data:
		{
			id : id
		},
		success: function(result){
			$("#city").removeAttr('disabled');
			result = JSON.parse(result);
			city = result.rajaongkir.results;
			for(var i=0;i<city.length;i++)
			{
				$('#city').append($('<option>', {
				    value: city[i].city_name,
				    text: city[i].city_name
				}));
			}
			
		}
	});
}

function changeCity()
{
	var id;
	$("#btnSubmit").attr('disabled','disabled');
	$("#service option").each(function() {
	    $(this).remove();
	});
	$("#service").attr('disabled','disabled');
	for(var i=0;i<city.length;i++)
	{
		if(city[i].city_name==$("#city").val())
			id = city[i].city_id;
	}
<?php //counting cart item
$cartItem = 0;
foreach($this->cart->contents() as $item)
{
	$cartItem += $item['qty'];
}
 ?>
	$.ajax({
		url: "<?php echo base_url() ?>/ongkir/cost.php",
		type: "POST",
		data:
		{
			dest : id,
			count: <?php echo $cartItem; ?>
		},
		success: function(result){
			$("#service").removeAttr('disabled');
			result = JSON.parse(result);
			result = result.rajaongkir.results[0];
			service = result.costs;
			$("#totalCost").html("Rp"+cost.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,'));
			for(var i=0;i<service.length;i++)
			{
				$("#service").append($('<option>', {
				    value: service[i].description,
				    text: service[i].description +" "+ service[i].cost[0].etd +" day(s)"
				}));
			}
		}
	});
}

function changeService()
{
	for(var i=0;i<service.length;i++)
	{
		if($("#service").val()==service[i].description)
		{
			$("#ongkosKirim").val(service[i].cost[0].value);
			$("#ongkosKirimDis").val(service[i].cost[0].value);
			var temp = cost + service[i].cost[0].value;
			$("#totalCost").html("Rp"+temp.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,'));
			$("#btnSubmit").removeAttr('disabled');
		}
	}
}
var r;
	
</script>