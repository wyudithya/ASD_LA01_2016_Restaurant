<div class="col-md-12">
	<div id="content" align="center">
		<div id="whiteBlock">
			Profile
		</div>
		<div id="fontStyle" class="innerContent" style="color:white;">
			<?php
				$attributes = array();
				echo form_open('EditProfile/input', $attributes); ?>

				  <div class="form-group col-md-12" style="padding:0">
				  	<div class="col-md-2 col-md-offset-3" style="padding:0">
				 		<label for="username">Username <span class="required">*</span></label>
				 	</div>
				 	<div class="col-md-4" style="padding:0">
				        <input class="form-control" style="display:none" id="username" type="text" name="username" maxlength="100" value="<?php if(set_value('username'))  echo set_value('username'); else if($value) echo $value['username']; ?>"  />
				        <input class="form-control" disabled id="" type="text" name="" maxlength="100" value="<?php if(set_value('username'))  echo set_value('username'); else if($value) echo $value['username']; ?>"  />
				        <?php echo form_error('username'); ?>
				    </div>
				  </div>
				  <div class="form-group col-md-12" style="padding:0">
				  	<div class="col-md-2 col-md-offset-3" style="padding:0">
					    <label for="name">Full Name <span class="required">*</span></label>
					 </div>
					 <div class="col-md-4" style="padding:0;">
				        <input class="form-control" id="name" type="text" name="name" maxlength="100" value="<?php if(set_value('name'))  echo set_value('name');  else if($value) echo $value['name']; ?>"  />
				       	<?php echo form_error('name'); ?>
				    </div>
				  </div>
				  <div class="form-group col-md-12" style="padding:0">
				  	<div class="col-md-2 col-md-offset-3" style="padding:0">
					    <label for="email">Email <span class="required">*</span></label>
					 </div>
					 <div class="col-md-4" style="padding:0;">
				        <input class="form-control" id="email" type="text" name="email" maxlength="100" value="<?php if(set_value('email'))  echo set_value('email'); else if($value) echo $value['email']; ?>"  />
				        <?php echo form_error('email'); ?>
				    </div>
				  </div>
				  <div class="form-group col-md-12" style="padding:0">
				  	<div class="col-md-2 col-md-offset-3" style="padding:0">
					   <label for="phone_number">Phone Number <span class="required">*</span></label>
					</div>
					<div class="col-md-4" style="padding:0;">
				        <input class="form-control" id="phone_number" type="text" name="phone_number" maxlength="100" value="<?php if(set_value('phone_number')) echo set_value('phone_number'); else if($value) echo  $value['phone_number'];?>"  />
				        <?php echo form_error('phone_number'); ?>
				    </div>
				  </div>
				  <div class="form-group col-md-12" style="padding:0">
				  	<div class="col-md-2 col-md-offset-3" style="padding:0">
					   <label for="date_of_birth">Date of Birth</label>
					</div>
					<div class="col-md-4" style="padding:0;">
				        <input class="form-control" type="date" id="date_of_birth" name="date_of_birth" maxlength="100" value="<?php if (set_value('date_of_birth')) echo date('Y-m-d',strtotime(set_value('date_of_birth'))); else if($value) echo date('Y-m-d',strtotime($value['date_of_birth'])); ?>"  />
				        <?php echo form_error('date_of_birth'); ?>
				    </div>
				  </div>
				  <div class="form-group col-md-12" style="padding:0">
				  	<div class="col-md-2 col-md-offset-3" style="padding:0">
					   <label for="address" style="vertical-align:top; line-height:7;">Address <span class="required">*</span></label>
					</div>
					<div class="col-md-4" style="padding:0">
						<?php echo form_textarea( array( 'name' => 'address', 'rows' => '5', 'cols' => '80', 'value' => (set_value('address')) ?  set_value('address') : $value['address'] ) )?>
						<?php echo form_error('address'); ?>
					</div>
				  </div>
				<br>
				<div class="col-md-12">
			  		<?php echo form_submit( 'submit', 'Update','class="btn brown col-md-6 col-md-offset-3"'); ?>
					<?php echo form_close(); ?>
				</div>
		</div>
	</div>
</div>
<style type="text/css">
	input[type="text"],[type="password"],[type="date"]{
		color :black;
	}
	label{
		text-align: left;
		float:left;
	}
	textarea{
		color :black;
		width:100%;
	}
</style>
<?php $this->load->view('FrontEnd/footer'); ?> 