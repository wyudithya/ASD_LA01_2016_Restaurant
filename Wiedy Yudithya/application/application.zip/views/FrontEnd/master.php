<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" type="image/png" href="<?php echo base_url() ?>assets/favicon.png">
	<?php 
	$data['title']=$title;
	$this->load->view('FrontEnd/externalLink',$data); 
	?>
</head>
<body>
	<?php $this->load->view('FrontEnd/header',$data); ?>
	<?php $this->load->view($content,$data); ?>
</body>
<script type="text/javascript">
//added by FS 5 Des
//atur footer biar dinamis
	$(document).ready(function()
	{
		if(window.innerHeight-$("#footer").offset().top>40)
			$("#footer").css("position","fixed");
	});
</script>
</html>