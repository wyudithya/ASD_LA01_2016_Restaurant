<div class="col-md-12">
	<div id="content">
		<div id="fontStyle" style="color:white;">
			<div id="whiteBlock">
				CART
			</div>
			<div class="col-xs-12 no-padding">
				<div class="col-xs-5">
					Item Description
				</div>
				<div class="col-xs-2">
					QTY
				</div>
				<div class="col-xs-4" align="right">
					Total
				</div>
			</div>
		<?php 
			$attributes = array('id' => 'submitForm');
			echo form_open('Cart/update',$attributes); 
		?>
		<?php $i = 1; ?>

		<?php foreach ($this->cart->contents() as $items): ?>

			<?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>

			<div class="col-xs-5" id="he">
				<?php echo $items['name']; ?>
				<div style="width:3em; float:right; height:1.5em; border: 1px solid black; background-color: <?php echo urldecode($items['color']); ?>">
				</div>
			</div>
			<div class="col-xs-2" id="he">
				<?php echo form_input(array('type'=>'number','name' => $i.'[qty]', 'value' => $items['qty'], 'maxlength' => '3', 'size' => '5','style' => 'max-width:50px;')); ?>
			</div>
			<div class="col-xs-4" id="he" align="right">
				Rp <?php echo $this->cart->format_number($items['subtotal']); ?>
			</div>
			<div class="col-xs-1" id="he"> 
				<a href="<?php echo base_url('Cart/delete'."/".$items['rowid']); ?>"><img src="<?php echo base_url() ?>assets/images/erase.png?>" style="max-height:30px;"></a>
			</div>

			<?php $i++; ?>
			<?php endforeach; ?>


			<div class="col-xs-offset-5 col-xs-2" id="he">
				Total 
			</div>
			<div class="col-xs-4" id="he" align="right">
				Rp <?php echo $this->cart->format_number($this->cart->total()); ?>
			</div>
			<div class="col-md-offset-7 col-md-4">
				<?php echo form_submit('', 'Update your Cart','class="btn btn-button pull-right" id="fontStyle" style="background-color:#774c29; display:none;"'); ?>
			</div> 
			<div class="col-md-offset-7 col-md-4" >
				<label class="btn btn-default pull-right" id="fontStyle" onclick="location.href = '<?php echo base_url('Home'); ?>';" style="background-color:#774c29; border:none;">Shop</button>
			</div>
			<div class="col-md-offset-7 col-md-4">
				<label id="fontStyle" class="btn btn-button pull-right" onclick="location.href = '<?php echo base_url('CheckOut'); ?>';" style="color:#774c29; background-color:white">Checkout</button>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('FrontEnd/footer'); ?> 
<style type="text/css">
	input[type="number"]{
		color :black;
	}
	#he{
		min-height: 100px;
		vertical-align: middle;
		padding-top:30px; 
	}
	input[type="submit"],label{
		margin-top: 10px;
		width: 150px;
	}
</style>
<script type="text/javascript">
	$(document).ready(function(){
		$( "input[type='number']" ).change(function() {
			$("#submitForm").submit();
		});
	});
</script>

