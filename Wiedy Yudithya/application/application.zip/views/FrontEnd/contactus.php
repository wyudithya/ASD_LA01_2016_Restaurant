<!DOCTYPE html>
<script src='https://www.google.com/recaptcha/api.js'></script>
<div class="col-md-12">
	<div id="content">
		<div class="col-md-8 innerContent" style="color:white; padding-top:5em; padding-bottom:5em;">
			<h1>ANY INQUIRIES?</h1>
			<h4>Drop a message and we will get back to you.</h4>
			<div id="fontStyle" style="color:white; margin-top:2em;">
			<?php
				$attributes = array();
				echo form_open('ContactUs/input', $attributes); ?>

				<div class="form-group col-md-12" style="margin-left:-30px">
					<div class="col-md-4">
				    	<label for="name">Name <span class="required">*</span></label>
				    </div>
				 	<div class="col-md-8">
				        <input required class="form-control" id="name" type="text" name="name" maxlength="100" value="<?php echo set_value('name'); ?>"  />
				      	<?php echo form_error('name'); ?>
			      	</div>
				</div>
				<div class="form-group col-md-12" style="margin-left:-30px">
					<div class="col-md-4">
				    	<label for="email">Email <span class="required">*</span></label>
				    </div>
				    <div class="col-md-8">
				        <input required class="form-control" id="email" type="text" name="email" maxlength="100" value="<?php echo set_value('email'); ?>"  />
				        <?php echo form_error('email'); ?>
			        </div>
				</div>
				<div class="form-group col-md-12" style="margin-left:-30px">
					<div class="col-md-4">
					   <label for="phone_number">Phone Number <span class="required">*</span></label>
					</div>
					<div class="col-md-8">
				        <input required class="form-control" id="phone_number" type="text" name="phone_number" maxlength="100" value="<?php echo set_value('phone_number'); ?>"  />
				        <?php echo form_error('phone_number'); ?>
				    </div>
				</div>
				<div class="form-group col-md-12" style="margin-left:-30px">
					<div class="col-md-4">
					    <label for="subject">Subject <span class="required">*</span></label>
				    </div>
					 <div class="col-md-8">
				        <input required class="form-control" id="subject" type="text" name="subject" maxlength="100" value="<?php echo set_value('subject'); ?>"  />
				      	<?php echo form_error('subject'); ?>
			      	</div>
				</div>
				<div class="form-group col-md-12" style="margin-left:-30px">
					<div class="col-md-4">
					   <label for="message" style="vertical-align:top; line-height:7">Message <span class="required">*</span></label>
					   </div>
					<div class="col-md-8">
						<?php echo form_textarea( array( 'name' => 'message','class'=>'form-control', 'rows' => '5', 'cols' => '80', 'value' => set_value('message') ) )?>
						<?php echo form_error('message'); ?>
					</div>
				</div>
				<div class="form-group col-md-12" style="margin-left:-30px">
					<div class="col-md-4">
					</div>
					<div class="col-md-8">
					<div class="g-recaptcha" data-sitekey="6LdADxMTAAAAAM3wYcye4CiewSchimb9lIVtV0Dv"></div>
					<?php if(isset($recaptcha_error))
								echo $recaptcha_error;
					?>
					</div>

				</div>

				<br>
				<div class="col-md-12" style="padding-left:0; padding-right:50px">
			  		<?php echo form_submit( 'submit', 'Send Message','class="btn btn-primary col-md-12" style="margin-right:30px; background-color:#774c29; border:none;"'); ?>
					<?php echo form_close(); ?>
				</div>

			</div>
	<!-- 		<table>
				<form>
					<tr>
						<td style="width:400px;">Name* <br>
						<input type="text" id="name" name="name" style="width:100%"></td>
					</tr>
					<tr>
						<td style="width:400px;">Email*<br>
						<input type="text" id="email" name="email" style="width:100%"></td>
					</tr>
					<tr>
						<td style="width:400px;">Subject<br>
						<input type="text" id="subject" name="subject" style="width:100%"></td>
					</tr>
					<tr>
						<td style="width:400px;">Message<br>
						<textarea  id="message" name="message" style="width:100%"></textarea></td>
					</tr>
				</form>
			</table> -->
		</div>
		<div class="col-md-4 innerContent" style="color:white;  padding-top:5em; padding-bottom:5em;">
			<h3>54VAPE TOMANG</h3>
			<h4>
				Jl. Tomang Raya No. 54 <br>
				Lantai 3 - Rooftop <br>
				Jakarta Barat
			</h4>
			<br>
			<h3>54VAPE TJ.DUREN</h3>
			<h4>
				Jl. Tj. Duren Barat 4 No. 1 <br>
				Jakarta Barat
			</h4>
			<br>
			<br>
			<h4>
				Business Hours:<br>
				Monday - Saturday<br>
				1 pm - 10 pm
				<br>
				<br>
				Business Inquiries:<br>
				info@54vape.com
				<br>
				<br>
				Follow us on instagram<br>
				@54vape
			</h4>
		</div>
	</div>
</div>
<style type="text/css">
	input[type="text"],[type="password"]{
		color :black;
		/*width: 	250px;*/
	}
	label{
		width: 	150px;
		text-align: left;
	}
	textarea{
		/*width: 	250px;*/
		color :black;
	}
</style>
<?php $this->load->view('FrontEnd/footer'); ?>
