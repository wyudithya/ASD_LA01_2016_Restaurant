</div>
<div id="footer" class="col-md-12" style="margin-top:5em">
	<div class="col-xs-8 text-left" style="padding-top:13px;">
		© COPYRIGHT 2015 - 54VAPE
	</div>
	<div class="col-xs-4 text-right">
		<span onclick="document.location = 'https://www.instagram.com/54vape/?hl=en'" class="fa fa-instagram" style="margin-right:0.5em; cursor:pointer; color:white"></span>
		<span style="cursor:pointer; color:white;" onclick="document.location = '<?php echo base_url() ?>ContactUs'" class="fa fa-envelope"></span>
	</div>
</div>