<div class="col-md-12">
	<div id="content">
		<div id="whiteBlock" style="margin:20px 0px;">
			CHECKOUT
		</div>
		<div class="col-md-12 no-padding" style="text-align:center;color:white;font-size:20px;">
			<p>Thank you. Your order has been received. <br>
			Kindly check your email for details and payment.
			</p>

		</div>
		<div class="row">
			<div class="col-md-4 col-md-offset-4 col-xs-8 col-xs-offset-2 ordernumber">
					ORDER NUMBER: <?php echo $trackingID; ?>
			</div>
		</div>
	
		<div id="whiteBlock" style="margin:20px 0px;">
				ORDER DETAILS
		</div>
		<div id="fontStyle" class="" style="color:white;">
				<div class="col-md-12 no-padding">
					<table class="col-md-8 col-xs-12 no-padding"cellpadding="6" cellspacing="1" style="border-collapse: separate;border-spacing: 10px 50px;" border="0">
						<tr style="font-size:20px;">
							<th>PRODUCT</th>
					  		<th>QTY</th>
							<th>TOTAL</th>
						</tr>


						<?php $grandTotal=0; for($i=0;$i<count($orderDetail);$i++){ ?>

						<tr style="font-size:20px;">
		 					<td>
								<?php echo $orderDetail[$i]->productName ?>

		  					</td>
		  					<td style="color:#774c29;">x<?php echo $orderDetail[$i]->qty ?></td>
		  					<td>
		  					Rp 
		  					<?php echo number_format($orderDetail[$i]->finalPrice, 0, ',', '.'); $grandTotal+=$orderDetail[$i]->finalPrice ?>
		  					</td>
						</tr>

						<?php } ?>

				</table>

				</div>
				<div class="col-md-12 no-padding" style="margin-top:20px;font-size:24px;">

				  	<div class="col-md-3 col-md-offset-3 col-xs -offset-3 col-xs-3"><strong>Shipping Cost</strong></div>
	 				<div class="col-md-3 col-xs-6"><strong>Rp<?php echo number_format($orderHeader->shippingCost, 0, ',', '.'); $grandTotal+=$orderHeader->shippingCost; ?></strong></div>
				</div>
				<div class="col-md-12 no-padding" style="margin-top:20px;font-size:24px;">

				  	<div class="col-md-3 col-md-offset-3 col-xs -offset-3 col-xs-3"><strong>Total</strong></div>
	 				<div class="col-md-3 col-xs-6"><strong>Rp<?php echo number_format($grandTotal, 0, ',', '.'); ?></strong></div>
				</div>
				<div style="margin-top:20px">
					<p style="font-size:24px;"><strong>CUSTOMER CONTACT</strong></p>
					<?php echo $orderHeader->recipientName ?><br>
					<?php echo $orderHeader->email ?><br>
					<?php echo $orderHeader->phoneNumber ?> <br>
					<br><br>

					<p style="font-size:24px;"><strong>BILLING ADDRESS</strong></p>
				<?php echo $orderHeader->address; ?>
				</div>

		</div>

	</div>
</div>
<style type="text/css">
</style>
<?php $this->load->view('FrontEnd/footer'); ?> 