<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<!-- modified by FS 10 Des ubah struktur, bug logout -->
<div id="header" class="col-md-12">
		<div class="col-md-4 col-md-offset-1 col-sm-3 col-sm-offset-1 logo-large" style="cursor:pointer" onclick="document.location='<?php echo base_url() ?>'">
			<img id="logo" src="<?php echo base_url();?>assets/images/logo.png" style="float:left;height:8em;margin-top:1.6em;">
		</div>
		<div class="col-md-6 col-sm-7">
			<div class="header1">
				<div class="row head1">
					<!-- modified by FS 1 Nov -->
					<div class="col-md-offset-3 col-md-8 col-sm-offset-3 col-sm-8 head3" id="headerHolder">	
						<div class="navbar navbar-default navbar-top" >		
								<!-- Start Navigation List -->
								<ul class="nav navbar-nav navbar-right" id="navbar-main" style="margin-top:0.6em;">
								<?php //counting cart item
								$cartItem = 0;
								foreach($this->cart->contents() as $item)
								{
									$cartItem += $item['qty'];
								}
								 ?>
									<?php if($this->session->userdata('username')!=null && $this->session->userdata('username')!="" ){
										?>
										<!-- modified by FS 5 Des -->
										<li class="dropdown navbar-materi">
											<a class="dropdown-toggle"  data-toggle="dropdown" href="<?php echo base_url() ?>User/profile/<?php $this->session->userdata('userid'); ?>"><?php echo $this->session->userdata('username');?> <span class="caret"></span></a>
											<ul class="dropdown-menu dropdown-shop userMenu no-padding">
												<li>
													<a class="" href="<?php echo base_url() ?>EditProfile">Edit Profile</a>
												</li>
												<li>
													<a class="" href="<?php echo base_url() ?>Order/track">Track Order</a>
												</li>
												<li>
													<a class="" href="<?php echo base_url() ?>Order/history">Order History</a>
												</li>
												<li>
													<a class="" href="<?php echo base_url() ?>Order/confirm">Confirm Payment</a>
												</li>
												<li style="float:none">
													<a class="" href="<?php echo base_url() ?>Login/logout">Logout</a>
												</li>
											</ul>
										</li>
										<li>
											<a class="navbar-materi" href="<?php echo base_url() ?>Cart">
												<span style="font-size:x-large" class="fa fa-shopping-cart"></span><span class="badge"><?php echo $cartItem; ?></span>
											</a>
										</li>
									<?php }else{?>
									<li>
										<a class="navbar-materi" href="<?php echo base_url('login'); ?>">LOGIN</a>
									</li>
									<li>
										<a class="navbar-materi" href="<?php echo base_url('register'); ?>">REGISTER</a>
									</li>
									<li>
										<a class="navbar-materi" href="<?php echo base_url() ?>Cart">
											<span style="font-size:x-large" class="fa fa-shopping-cart"></span><span class="badge"><?php echo $cartItem; ?></span>
										</a>
									</li>
									<?php } ?>
								</ul>
								<!-- End Navigation List -->
						</div>
						<!-- End Header Logo & Naviagtion -->
					</div>
				</div>
				
				<!--Versi Small-->
				<div class="row head1-small" style="margin:0">
					<div class="col-xs-12 navbar navbar-default navbar-top" style="margin:0">		
							<!-- Start Navigation List -->
							<ul class="nav navbar-nav navbar-right" id="navbar-main" style="margin-top:0.6em;">
								<?php if($this->session->userdata('username')!=null && $this->session->userdata('username')!="" ){
									?>
									<!-- modified by FS 5 Des -->
									<li class="dropdown col-md-3 col-xs-4 no-padding">
										<a class="dropdown-toggle"  data-toggle="dropdown" href="<?php echo base_url() ?>User/profile/<?php $this->session->userdata('userid'); ?>"><?php echo $this->session->userdata('username');?> <span class="caret"></span></a>
										<ul class="dropdown-menu dropdown-shop userMenu no-padding">
											<li>
												<a class="" href="<?php echo base_url() ?>Order/track">Track Order</a>
											</li>
											<li>
												<a class="" href="<?php echo base_url() ?>Order/history">Order History</a>
											</li>
											<li>
												<a class="" href="<?php echo base_url() ?>Order/confirm">Confirm Payment</a>
											</li>
											<li style="float:none">
												<a class="" href="<?php echo base_url() ?>Login/logout">Logout</a>
											</li>
										</ul>
									</li>
									<li>
										<a class="navbar-materi" href="<?php echo base_url() ?>Cart">
											<span style="font-size:x-large" class="fa fa-shopping-cart"></span><span class="badge"><?php echo $cartItem; ?></span>
										</a>
									</li>
								<?php }else{?>
								<li class="col-xs-offset-1 col-xs-3 no-padding">
									<a class="navbar-materi" href="<?php echo base_url('login'); ?>">LOGIN</a>
								</li>
								<li class="col-xs-4 no-padding">
									<a class="navbar-materi" href="<?php echo base_url('register'); ?>">REGISTER</a>
								</li>
								<li class="col-xs-3 no-padding">
									<a class="navbar-materi" href="<?php echo base_url() ?>Cart">
										<span style="font-size:x-large" class="fa fa-shopping-cart"></span><span class="badge"><?php echo $cartItem; ?></span>
									</a>
								</li>
									<?php } ?>
							</ul>
							<!-- End Navigation List -->
				
						<!-- End Header Logo & Naviagtion -->
					</div>
				</div>
				<div class="row">
					<div class="col-md-2 col-md-offset-1 col-sm-12 col-xs-12 col-sm-offset-1 logo-small">
						<img id="logo" class="col-xs-12" src="<?php echo base_url();?>assets/images/logo.png" style="margin-bottom:1.2em;">
					</div>
				</div>
			</div>
			<!--Versi Small-->	
		</div>
</div>
<div class="col-md-12">
	<div id="menubar" class="menu">
		<div class="navbar navbar-default navbar-top" >		
				<!-- Start Navigation List -->
			<ul class="nav" style="margin-top:0.6em;">
				<li class="col-md-3 col-xs-4 no-padding">
					<a class="active" href="<?php echo base_url('Home'); ?>">HOME</a>
				</li>
				<li class="dropdown col-md-3 col-xs-4 no-padding">
					<a class="dropdown-toggle"  data-toggle="dropdown" href="#">SHOP <span class="caret"></span></a>
					<ul class="dropdown-menu dropdown-shop">

					<?php for($i=0;$i<count($category);$i++){ ?>
						<li style="cursor:pointer;" class="dropdown-header">
							<a style="padding-left:0" href="<?php echo base_url() ?>Category/view/<?php echo $category[$i]->categoryID; ?>"><?php echo $category[$i]->categoryName; ?></a>
						</li>
						<?php for($j=0;$j<count($category[$i]->childCategory);$j++){ ?>
							<li>
								<a class="dropdown-body" href="<?php echo base_url() ?>Category/view/<?php echo $category[$i]->childCategory[$j]->categoryID ?>"><?php echo $category[$i]->childCategory[$j]->categoryName ?></a>
							</li>
						<?php } ?>
					<?php } ?>
					 </ul>
				</li>
				<li class="col-md-3 col-xs-4 no-padding">
					<a class="" href="<?php echo base_url('ContactUs'); ?>">CONTACT</a>
				</li>
				<div class="col-md-3 col-xs-12 no-padding">
				<form action="<?php echo base_url() ?>Home/search" method="get">
					<div id="custom-search-input">
						<div class="input-group col-md-12">
		    				<input name="q" type="text" class="search-query form-control"/>
		    				<span class="input-group-btn">
		        				<button class="btn" type="submit">
		            				<span class=" glyphicon glyphicon-search"></span>
		        				</button>
		   					</span>
						</div>
					</div>
				</form>
				</div>
			</ul>
		</div>
	</div>
</div>
<style>
#menubar{
	    width:80%;
			margin: 0 auto;
}
.menu .navbar-default .nav > li > a {
		color: white;
}

.navbar-default .nav > li > a:hover, .navbar-default .nav  > li > a:focus {
	/*modified by FS 5 Des*/
		/*color: #774c29; */
		color:white;
			/*background-color: rgba(1,1,1,0.2);*/
			background-color:transparent;
			border:1px solid white; 
}

#custom-search-input {
    margin:0;
    padding: 0;
}

#custom-search-input .search-query {

    height: 3em;
    background-color:transparent;
    /* IE7-8 doesn't have border-radius, so don't indent the padding */
    color: white;
    border:3px solid transparent; 
}

#custom-search-input{
	margin-bottom: 0;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    border-radius: 3px;
    color: white;
    border:3px solid white; 
}

#custom-search-input button {
    border: 0;
    background: none;
    /** belows styles are working good */
    padding: 2px 5px;
    margin-top: 2px;
    position: relative;
    /* IE7-8 doesn't have border-radius, so don't indent the padding */
    margin-bottom: 0;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    border-radius: 3px;
    color:white;
}

.search-query:focus + button {
    z-index: 3;   
}


ul.dropdown-shop li a{
	padding-left: 40px;
	color: #774c29;
}

ul.dropdown-shop li a:hover{
	color: white;
	background-color:#774c29;
}

ul.dropdown-shop li.dropdown-header{
	font-size: 14px;
	color: #774c29;
}

</style>