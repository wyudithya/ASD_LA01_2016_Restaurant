<style type="text/css">
	div.inline { display: inline-block; }
	.border-foto{
		border: 1px solid #cfcfcf;
	}
</style>
<div class="col-md-12">
	<div id="content">
		<div class="col-md-12 no-padding" style="margin-top:2em;">	
			<div class="title"><b>
					<div class="inline" style="color:white">Home > Shop > <?php echo $detailProduct['CategoryName'];?></h2></div>
					<div class="inline" style="color:#774c29"> > <?php echo $detailProduct['ProductName'];?></h5></div>
				</b>
			</div>
			<div class="detail_product col-md-12 no-padding" style="margin-top:1em;color:white">
					<div class="photo-product col-md-6">
						<div class="row">
							<div class="col-md-12 no-padding" style="padding: 0px 5px">
								<img name="preview" class="border-foto product-thumb img-responsive centered" src="<?php echo base_url().'assets/Products/'.$detailProduct['Photo'][0]?>" onError="this.onerror=null; this.src='<?php echo base_url(); ?>assets/images/notAvailable.jpg';"alt="..." >
							</div>
						</div>

						<div class="row" style="margin-top:20px;">
						<!--Bootstrap 15 untuk 5 layout-->
							<?php for($i=0;$i<sizeof($detailProduct['Photo']);$i++){?>
							<div class="col-md-15 col-xs-15 col-sm-15 no-padding" style="padding: 0px 5px;">
								<div class="border-foto">
									<img name="image<?php echo $i?>" onmouseover="preview.src=image<?php echo $i?>.src" class="product-thumb img-responsive centered" src="<?php echo base_url().'assets/Products/'.$detailProduct['Photo'][$i]?>" onError="this.onerror=null; this.src='<?php echo base_url(); ?>assets/images/notAvailable.jpg';"alt="..." >
								</div>
							</div>
							<?php } ?>
						</div>
					</div>
					<div class="description-product col-md-6 no-padding">
						<div id="header-description">
							<div id="product-name" style="font-size:xx-large">
								<b><?php echo $detailProduct['ProductName'];?></b><br>
							</div>
							<div id="product-price" style="font-size:20px">									
							<!--Cetak Price-->
							<b>
								<?php 
									if(isset($detailProduct['Price'])){ ?>
									<span <?php if($detailProduct["Discount"]>0) echo 'style="text-decoration:line-through"'; ?>>
										<?php 
									echo "Rp. ";
									echo number_format($detailProduct['Price'], 0, ',', '.'); ?>
									</span>
									<?php if($detailProduct["Discount"]>0) { ?>
									<br><span style="font-size:x-large">
										<?php 
									echo "Rp. ";
									echo number_format($detailProduct['Price']*(100-$detailProduct["Discount"])/100, 0, ',', '.'); ?>
									</span>
									<?php } ?>
									<?php
									}else{
									echo "Rp. ";
									echo '-';
										}
									?></b>
							<!--Price-->
							</div>
						</div>
						<div id="body-description" style="text-align:justify;margin-top:20px;">
								<?php echo $detailProduct['shortDescription'];?>
						</div>

						<div id="pick-color" style="margin:20px 0px; font-size:18px">
							<div class="inline" style="height:30px;">Color
							</div>
							<div class="box-product inline" style="height: 30px;width:30px; background-color:<?php echo $detailProduct["color"] ?>;margin-left:10px; cursor:pointer">
							</div>
							<?php for($i=0;$i<count($detailProduct['otherColor']);$i++){ ?>
							<div onclick="document.location = '<?php echo base_url() ?>Home/detail_product/<?php echo $detailProduct['otherColor'][$i]->productID ?>'" class="box-product inline" style="height: 30px;width:30px; background-color:<?php echo $detailProduct['otherColor'][$i]->color ?>; cursor:pointer">
							</div>
							<?php } ?>
						</div>
						<div>		
							<input placeholder="Qty" class="form-control" style="width : 75px;color:brown" value="1"  type="number" min="1" name="qty" id="qty">
							<button id="cart" style="width:150px;margin-top:10px;" type="button" value="YOUR CART" class="btn brown">ADD TO CART</span></button>
							
						</div>

						<div style="text-align:justify;margin-top:20px;">
							<?php echo $detailProduct['ProductDesc'];?>
						</div>
					</div>
			</div>
	</div>
</div>
<?php $this->load->view('FrontEnd/footer'); ?>
<script src="<?php echo base_url();?>assets/owl-carousel/owl.carousel.js"></script>
<script>
	$(document).ready(function(){
		$("#cart").click(function(){
			str = '<?php echo $detailProduct['ProductName'];?>';
			name = str.replace(' ','-');
			var color = '<?php  echo $detailProduct['color']; ?>';
			price = <?php echo $detailProduct['Price']?>;
			document.location='<?php echo base_url()?>Home/cart/<?php echo $detailProduct['ProductID']?>'+'/<?php echo $detailProduct['Discount']?>'+'/'+$("#qty").val()+'/'+price+'/'+name+'/'+encodeURIComponent(color);
		});
		$("h1").css('font-family','defaultFont');
		$("h2").css('font-family','defaultFont');
		$("h3").css('font-family','defaultFont');
		$("h4").css('font-family','defaultFont');
		$("h5").css('font-family','defaultFont');
		$("h6").css('font-family','defaultFont');
	});
</script>