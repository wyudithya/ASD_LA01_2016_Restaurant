<!DOCTYPE html>

	<div id="content">
		<div class="col-md-9 no-padding" style="margin-top:2em;">
			<div class="box white right bottom">
					<h2 class="title">About Us</h2>
					<div class="contact center">
						<h2><b>Who we are</b></h2>
						<div>
							<p class="text-content" style="word-wrap:break-word;"> Kami adalah aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
							aaaaaadalah aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
							adalah aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
							adalah aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</p>
						</div>
					</div>
				</div>
		</div>
		<div class="col-md-3 no-padding" style="margin-top:2em;">
			<div class="box white bottom center">
				<h3>FOLLOW US</h3>
				<div class="top">
					<i class="fa fa-facebook round right-s"></i>
					<i class="fa fa-twitter round right-s"></i>
					<i class="fa fa-instagram round" ></i>
				</div>
			</div>			
		</div>
	</div>
	<?php $this->load->view('FrontEnd/footer'); ?>

<script>
    $('.carousel').carousel({
        interval: 3000
    })
</script>