<style type="text/css">
	div.inline { display: inline-block; }
	.customNavigation{ float: right!important;margin: 3px;}
</style>
<div class="col-md-12 no-padding">
	<div id="content">
		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		  <!-- Indicators -->
		  <ol class="carousel-indicators">
		  	<?php for($i=0;$i<count($banner);$i++) { ?>
		    <li data-target="#carousel-example-generic" data-slide-to="<?php echo $i; ?>" <?php if($i==0) echo 'class="active"'; ?>></li>
		    <?php } ?>
		  </ol>
		 
		  <!-- Wrapper for slides -->
		  <div class="carousel-inner">
		  <?php for($i=0;$i<count($banner);$i++){ ?>
		    <div style="cursor:pointer" onclick="document.location = '<?php echo base_url('Home/detail_product'."/".$banner[$i]->ProductID); ?>'" class="item <?php if($i==0) echo "active"; ?>">
		      <img src="<?php echo base_url() ?>assets/Products/<?php echo $banner[$i]->photo; ?>">
		      <div class="carousel-caption">
		          <h3><?php echo $banner[$i]->ProductName ?></h3>
		      </div>
		    </div>
		   <?php } ?>
		 
		  <!-- Controls -->
		  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
		    <span class="glyphicon glyphicon-chevron-left"></span>
		  </a>
		  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
		    <span class="glyphicon glyphicon-chevron-right"></span>
		  </a>
		</div> <!-- Carousel -->
</div>
<?php $this->load->view('FrontEnd/footer'); ?> 
<script src="<?php echo base_url();?>assets/owl-carousel/owl.carousel.js"></script>
<style>
    #owl-newproducts .item{
        padding: 10px;
        margin: 10px;
        background-color: white;
        text-align: center;
    }

    #owl-featuredproducts .item, #owl-discountedproducts .item, #owl-popularproducts .item{
        padding: 10px;
        margin: 10px;
        background-color: white;
        text-align: center;
    }

    .customNavigation{
      text-align: center;
    }
    .customNavigation a{
      -webkit-user-select: none;
      -khtml-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    }
    .owl-item:first-child>a>.item
    {
    	margin-left: 0 !important;
    }
    .dicount-text
    {
    	position: absolute;
	    top: 0;
	    left: 0;
	    font-size: 1.5em;
	    padding-left: 0.5em;
	    padding-right: 0.5em;
	    padding-top: 0.8em;
    }
    .discount-star
    {
    	width: 90px;
    }
    .box-discount
    {
    	top:-5px;
    }
</style>
<script>
$(document).ready(function() {
	$('.carousel').carousel({
        interval: 3000
    })
	  //New-Products
      var owl = $("#owl-newproducts");
      owl.owlCarousel({
      items : 4, //10 items above 1000px browser width
      itemsDesktop : [1000,2], //5 items between 1000px and 901px
      itemsDesktopSmall : [900,2], // 3 items betweem 900px and 601px
      itemsTablet: [600,1], //2 items between 600 and 0;
      itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
      });

      $(".new-products-next").click(function(){
        owl.trigger('owl.next');
      })
      $(".new-products-prev").click(function(){
        owl.trigger('owl.prev');
      })
      //----End New Products

      //Featured-Products
      var owl1 = $("#owl-featuredproducts");
      owl1.owlCarousel({
      items : 4, //10 items above 1000px browser width
      itemsDesktop : [1000,2], //5 items between 1000px and 901px
      itemsDesktopSmall : [900,2], // 3 items betweem 900px and 601px
      itemsTablet: [600,1], //2 items between 600 and 0;
      itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
      });


      $(".featured-products-next").click(function(){
        owl1.trigger('owl.next');
      })
      $(".featured-products-prev").click(function(){
        owl1.trigger('owl.prev');
      })

      //End Featured-Products

      //discounted products
      var owl2 = $("#owl-discountedproducts");
      owl2.owlCarousel({
      items : 4, //10 items above 1000px browser width
      itemsDesktop : [1000,2], //5 items between 1000px and 901px
      itemsDesktopSmall : [900,2], // 3 items betweem 900px and 601px
      itemsTablet: [600,1], //2 items between 600 and 0;
      itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
      });


      $(".discounted-products-next").click(function(){
        owl2.trigger('owl.next');
      })
      $(".discounted-products-prev").click(function(){
        owl2.trigger('owl.prev');
      })
      //End discounted products

      //popular products
      var owl2 = $("#owl-popularproducts");
      owl2.owlCarousel({
      items : 4, //10 items above 1000px browser width
      itemsDesktop : [1000,2], //5 items between 1000px and 901px
      itemsDesktopSmall : [900,2], // 3 items betweem 900px and 601px
      itemsTablet: [600,1], //2 items between 600 and 0;
      itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
      });


      $(".popular-products-next").click(function(){
        owl2.trigger('owl.next');
      })
      $(".popular-products-prev").click(function(){
        owl2.trigger('owl.prev');
      })
      //End popular products


});


</script>
<script src="<?php echo base_url();?>assets/js/bootstrap-collapse.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap-transition.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap-tab.js"></script>