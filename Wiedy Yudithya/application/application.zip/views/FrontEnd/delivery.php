<!DOCTYPE html>
<div class="col-md-12">
	<div id="content">
		<div class="col-xs-8 col-xs-offset-2 no-padding" style="margin-top:2em;">
			<div class="box white bottom" style="width:100%;">
				<h2 class="title">Delivery Information</h2>
				<div class="col-md-offset-2 col-md-8 form">
					<form action="">
						<div class="row">
							<div class="col-md-3 text-form no-padding">
								Street/Building <red> *</red>
							</div>
							<div class="col-md-9">
								<textarea rows="2" class="pink textArea"name="txtStreet" id="txtStreet">
								</textarea>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3 text-form no-padding">
								Substreet
							</div>
							<div class="col-md-9">
								<input type="text" class="pink text" name="txtSubStreet" id="txtSubStreet">
							</div>
						</div>
						<div class="row">
							<div class="col-md-3 text-form no-padding">
								Kav/No <red>*</red>
							</div>
							<div class="col-md-9">
								<input type="text" class="pink text" name="txtKav" id="txtKav">
							</div>
						</div>
						<div class="row">
							<div class="col-md-3 text-form no-padding">
								Place/Level
							</div>
							<div class="col-md-9">
								<input type="text" class="pink text" name="txtPlace" id="txtPlace">
							</div>
						</div>
						<div class="row">
							<div class="col-md-3 text-form no-padding">
								City Region <red>*</red>
							</div>
							<div class="col-md-9">
								<input type="text" class="pink text" name="txtCity" id="txtCity">
							</div>
						</div>
						<div class="row">
							<div class="col-md-3 text-form no-padding">
								Province <red>*</red>
							</div>
							<div class="col-md-9">
								<input type="text" class="pink text" name="txtProvince" id="txtProvince">
							</div>
						</div>
						<div class="row">
							<div class="col-md-3 text-form no-padding">
								Post Code <red>*</red>
							</div>
							<div class="col-md-9">
								<input type="text" class="pink text" name="txtPost" id="txtPost">
							</div>
						</div>
						<div class="row">
							<div style="float:right;">
								<red>* :</red><b>Required fields</b>
							</div>
						</div>
						<div class="row">
							<button type="submit" class="btn brown center col-md-offset-4 col-md-3 col-sm-offset-4 col-sm-3" style="width:10em;margin-top:1.5em;">
							Review Order
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('FrontEnd/footer'); ?>

<script>
    $('.carousel').carousel({
        interval: 3000
    })
</script>