<style type="text/css">
	div.inline { display: inline-block; }
	.customNavigation{ float: right!important;margin: 3px;}
</style>
<div class="col-md-12">
	<div id="content">
		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		  <!-- Indicators -->
		  <ol class="carousel-indicators">
		  	<?php for($i=0;$i<count($banner);$i++) { ?>
		    <li data-target="#carousel-example-generic" data-slide-to="<?php echo $i; ?>" <?php if($i==0) echo 'class="active"'; ?>></li>
		    <?php } ?>
		  </ol>
		 
		  <!-- Wrapper for slides -->
		  <div class="carousel-inner">
		  <?php for($i=0;$i<count($banner);$i++){ ?>
		    <div style="cursor:pointer" onclick="document.location = '<?php echo base_url('Home/detail_product'."/".$banner[$i]->ProductID); ?>'" class="item <?php if($i==0) echo "active"; ?>">
		      <img src="<?php echo base_url() ?>assets/Products/<?php echo $banner[$i]->photo; ?>">
		      <div class="carousel-caption">
		          <h3><?php echo $banner[$i]->ProductName ?></h3>
		      </div>
		    </div>
		   <?php } ?>
		 
		  <!-- Controls -->
		  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
		    <span class="glyphicon glyphicon-chevron-left"></span>
		  </a>
		  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
		    <span class="glyphicon glyphicon-chevron-right"></span>
		  </a>
		</div> <!-- Carousel -->

		<div class="col-md-9 no-padding">
			<div id="whiteBlock" style="margin-right:30px">
				<button class="btn new-products-prev" style="margin-left:15px;"><span class="fa fa-angle-left"></span></button>
				<button class="btn new-products-next"><span class="fa fa-angle-right"></span></button>
				New Products
				<span style="float:right; margin-right:15px"><a href="<?php echo base_url(); ?>Products/newest/0">See All</a></span>
			</div>
			<!-- Carousel -->
			<div id="owl-newproducts" class="owl-carousel" style="padding-right:30px;">
			<!-- modified by FS 1 Des -->
			<!-- ini cara buat satuin product sama dengan warna" yang beda -->
			<?php $tempName = "";
			for($i=0;$i<sizeof($newproducts);$i++){
				if($tempName==$newproducts[$i]['ProductName'])
					continue;
				else
					$tempName = $newproducts[$i]['ProductName']; 
				if(isset($newproducts[$i]['ProductID'])){?>
			<a href="<?php echo base_url('Home/detail_product'."/".$newproducts[$i]['ProductID']);?>" style="color:black;text-decoration: none;">
			<?php } ?>
				<div class="item">
				<?php if(isset($newproducts[$i]["Discount"])&&$newproducts[$i]["Discount"]>0){ ?>
					<div class="box-discount">
						<img src="<?php echo base_url() ?>assets/images/star.png" class="discount-star">
						<span class="dicount-text">
							<?php echo $newproducts[$i]["Discount"]; ?>% OFF
						</span>
					</div>
				<?php } ?>
				<div class="product">
					<div class="box-product">
						<?php
							if(isset($newproducts[$i]['Thumbnail'])){
						?>
							<img class="product-thumb img-responsive centered" src="<?php echo base_url().'assets/Products/thumb/'.$newproducts[$i]['Thumbnail']?>" onError="this.onerror=null; this.src='<?php echo base_url(); ?>assets/images/notAvailable.jpg';"alt="..." >
						<?php } ?>
					</div>
					<h4 style="min-height:2em;">
						<?php 
							if(isset($newproducts[$i]['ProductName']))
								echo $newproducts[$i]['ProductName'];
							else
								echo '-';
						?>
					</h4>
					<div class="box-price">
						<?php 
							if(isset($newproducts[$i]['Price'])){
								echo "Rp. ";
								echo number_format($newproducts[$i]['Price']*(100-$newproducts[$i]['Discount'])/100, 0, ',', '.');
							}else{
								echo "Rp. ";
								echo '-';
							}
						?>
					</div>
				</div>
				</div>
			</a>
			<?php }?>
			</div>
			<!-- Carousel -->
			<div id="whiteBlock" style="margin-right:30px">
				<button class="btn featured-products-prev" style="margin-left:15px;"><span class="fa fa-angle-left"></span></button>
				<button class="btn featured-products-next"><span class="fa fa-angle-right"></span></button>
				Featured Products
				<span style="float:right; margin-right:15px"><a href="<?php echo base_url(); ?>Products/featured/0">See All</a></span>
			</div>
			<!-- Carousel -->
			<div id="owl-featuredproducts" class="owl-carousel" style="padding-right:30px;">
			<!-- modified by FS 1 Des -->
			<?php $tempName = "";
			 for($i=0;$i<sizeof($featuredproducts);$i++){
			 	if($tempName==$featuredproducts[$i]["ProductName"])
			 		continue;
			 	else
			 		$tempName = $featuredproducts[$i]["ProductName"];
				if(isset($featuredproducts[$i]['ProductID'])){?>
			<a href="<?php echo base_url('Home/detail_product'."/".$featuredproducts[$i]['ProductID']);?>" style="color:black;text-decoration: none;">
				<?php } ?>
				<div class="item">
				<?php if(isset($featuredproducts[$i]["Discount"])&&$featuredproducts[$i]["Discount"]>0){ ?>
					<div class="box-discount">
						<img src="<?php echo base_url() ?>assets/images/star.png" class="discount-star">
						<span class="dicount-text">
							<?php echo $featuredproducts[$i]["Discount"]; ?>% OFF
						</span>
					</div>
				<?php } ?>
				<div class="product">
					<div class="box-product">
						<?php
							if(isset($featuredproducts[$i]['Thumbnail'])){
						?>
							<img class="product-thumb img-responsive centered" src="<?php echo base_url().'assets/Products/thumb/'.$featuredproducts[$i]['Thumbnail']?>" onError="this.onerror=null; this.src='<?php echo base_url(); ?>assets/images/notAvailable.jpg';"alt="..." >
						<?php } ?>
					</div>
					<h4 style="min-height:2em;">
						<?php 
							if(isset($featuredproducts[$i]['ProductName']))
								echo $featuredproducts[$i]['ProductName'];
							else
								echo '-';
						?>
					</h4>
					<div class="box-price">
						<?php 
							if(isset($featuredproducts[$i]['Price'])){
								echo "Rp. ";
								echo number_format($featuredproducts[$i]['Price']*(100-$featuredproducts[$i]['Discount'])/100, 0, ',', '.');
							}else{
								echo "Rp. ";
								echo '-';
							}
						?>
					</div>
				</div>
				</div>
			</a>
			<?php }?>
			</div>
			<div id="whiteBlock" style="margin-right:30px;">
				<button class="btn discounted-products-prev" style="margin-left:15px;"><span class="fa fa-angle-left"></span></button>
				<button class="btn discounted-products-next"><span class="fa fa-angle-right"></span></button>
				Discounted Products
				<span style="float:right; margin-right:15px"><a href="<?php echo base_url(); ?>Products/discount/0">See All</a></span>
			</div>
			<!-- Carousel -->
			<div id="owl-discountedproducts" class="owl-carousel" style="padding-right:30px;">
			<!-- modified by FS 1 Des -->
			<?php $tempName = "";
			 for($i=0;$i<sizeof($discounted);$i++){
			 	if($tempName==$discounted[$i]["ProductName"])
			 		continue;
			 	else
			 		$tempName = $discounted[$i]["ProductName"];
				if(isset($discounted[$i]['ProductID'])){?>
			<a href="<?php echo base_url('Home/detail_product'."/".$discounted[$i]['ProductID']);?>" style="color:black;text-decoration: none;">
				<?php } ?>
				<div class="item">
				<?php if(isset($discounted[$i]["Discount"])&&$discounted[$i]["Discount"]>0){ ?>
					<div class="box-discount">
						<img src="<?php echo base_url() ?>assets/images/star.png" class="discount-star">
						<span class="dicount-text">
							<?php echo $discounted[$i]["Discount"]; ?>% OFF
						</span>
					</div>
				<?php } ?>
				<div class="product">
					<div class="box-product">
						<?php
							if(isset($discounted[$i]['Thumbnail'])){
						?>
							<img class="product-thumb img-responsive centered" src="<?php echo base_url().'assets/Products/thumb/'.$discounted[$i]['Thumbnail']?>" onError="this.onerror=null; this.src='<?php echo base_url(); ?>assets/images/notAvailable.jpg';"alt="..." >
						<?php } ?>
					</div>
					<h4 style="min-height:2em;">
						<?php 
							if(isset($discounted[$i]['ProductName']))
								echo $discounted[$i]['ProductName'];
							else
								echo '-';
						?>
					</h4>
					<div class="box-price">
						<?php 
							if(isset($discounted[$i]['Price'])){
								echo "Rp. ";
								echo number_format($discounted[$i]['Price']*(100-$discounted[$i]['Discount'])/100, 0, ',', '.');
							}else{
								echo "Rp. ";
								echo '-';
							}
						?>
					</div>
				</div>
				</div>
			</a>
			<?php }?>
			</div>
			<div id="whiteBlock" style="margin-right:30px;">
				<button class="btn popular-products-prev" style="margin-left:15px;"><span class="fa fa-angle-left"></span></button>
				<button class="btn popular-products-next"><span class="fa fa-angle-right"></span></button>
				Popular Products
				<span style="float:right; margin-right:15px"><a href="<?php echo base_url(); ?>Products/popular/0">See All</a></span>
			</div>
			<!-- Carousel -->
			<div id="owl-popularproducts" class="owl-carousel" style="padding-right:30px;">
			<!-- modified by FS 1 Des -->
			<?php $tempName = "";
			 for($i=0;$i<sizeof($popular);$i++){
			 	if($tempName==$popular[$i]["ProductName"])
			 		continue;
			 	else
			 		$tempName = $popular[$i]["ProductName"];
				if(isset($popular[$i]['ProductID'])){?>
			<a href="<?php echo base_url('Home/detail_product'."/".$popular[$i]['ProductID']);?>" style="color:black;text-decoration: none;">
				<?php } ?>
				<div class="item">
				<?php if(isset($popular[$i]["Discount"])&&$popular[$i]["Discount"]>0){ ?>
					<div class="box-discount">
						<img src="<?php echo base_url() ?>assets/images/star.png" class="discount-star">
						<span class="dicount-text">
							<?php echo $popular[$i]["Discount"]; ?>% OFF
						</span>
					</div>
				<?php } ?>
				<div class="product">
					<div class="box-product">
						<?php
							if(isset($popular[$i]['Thumbnail'])){
						?>
							<img class="product-thumb img-responsive centered" src="<?php echo base_url().'assets/Products/thumb/'.$popular[$i]['Thumbnail']?>" onError="this.onerror=null; this.src='<?php echo base_url(); ?>assets/images/notAvailable.jpg';"alt="..." >
						<?php } ?>
					</div>
					<h4 style="min-height:2em;">
						<?php 
							if(isset($popular[$i]['ProductName']))
								echo $popular[$i]['ProductName'];
							else
								echo '-';
						?>
					</h4>
					<div class="box-price">
						<?php 
							if(isset($popular[$i]['Price'])){
								echo "Rp. ";
								echo number_format($popular[$i]['Price']*(100-$popular[$i]['Discount'])/100, 0, ',', '.');
							}else{
								echo "Rp. ";
								echo '-';
							}
						?>
					</div>
				</div>
				</div>
			</a>
			<?php }?>
			</div>
		</div>
		<div class="col-md-3 no-padding">
			<div class="box white bottom center">
				<h3>FOLLOW US</h3>
				<div class="top">
					<i style="cursor:pointer" onclick="document.location='https://www.facebook.com/sharer/sharer.php?u=http%3A//www.54vape.com'" class="fa fa-facebook round right-s"></i>
					<i style="cursor:pointer" onclick="document.location='https://twitter.com/home?status=Check%20out%20http%3A//54vape.com%20!'" class="fa fa-twitter round right-s"></i>
					<i style="cursor:pointer" onclick="document.location = 'https://www.instagram.com/54vape/?hl=en'" class="fa fa-instagram round" ></i>
				</div>
			</div>		
			<div class="box white bottom center">
				<h3>HOT ITEMS</h3>
				<?php $tempName = "";
				for($i=0;$i<sizeof($hotitems);$i++){
					if($tempName==$hotitems[$i]['ProductName'])
						continue;
					else
						$tempName = $hotitems[$i]['ProductName'];
					?>
				<a href="<?php echo base_url('Home/detail_product'."/".$hotitems[$i]['ProductID']);?>" style="color:black;text-decoration: none;">
					<div class="col-md-12">
						<div class="product">
							<?php if(isset($hotitems[$i]["Discount"])&&$hotitems[$i]["Discount"]>0){ ?>
								<div class="box-discount" style="top:-30px">
									<img src="<?php echo base_url() ?>assets/images/star.png" class="discount-star">
									<span class="dicount-text">
										<?php echo $hotitems[$i]["Discount"]; ?>% OFF
									</span>
								</div>
							<?php } ?>
							<div class="box-product">

								<?php
									if(isset($hotitems[$i]['Thumbnail'])){
								?>
									<img class="product-thumb img-responsive centered" src="<?php echo base_url().'assets/Products/thumb/'.$hotitems[$i]['Thumbnail']?>" onError="this.onerror=null; this.src='<?php echo base_url(); ?>assets/images/notAvailable.jpg';"alt="..." >
								<?php } ?>
							</div>
							<h4>
								<?php 
									if(isset($hotitems[$i]['ProductName']))
										echo $hotitems[$i]['ProductName'];
									else
										echo '-';
								?>
							</h4>
							<div class="box-price bottom">
								<?php 
									if(isset($hotitems[$i]['Price'])){
										echo "Rp. ";
										echo number_format($hotitems[$i]['Price'], 0, ',', '.');
									}else{
										echo "Rp. ";
										echo '-';
									}
								?>
							</div>
						</div>
					</div>
				</a>
				<?php }?>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('FrontEnd/footer'); ?> 
<script src="<?php echo base_url();?>assets/owl-carousel/owl.carousel.js"></script>
<style>
    #owl-newproducts .item{
        padding: 10px;
        margin: 10px;
        background-color: white;
        text-align: center;
    }

    #owl-featuredproducts .item, #owl-discountedproducts .item, #owl-popularproducts .item{
        padding: 10px;
        margin: 10px;
        background-color: white;
        text-align: center;
    }

    .customNavigation{
      text-align: center;
    }
    .customNavigation a{
      -webkit-user-select: none;
      -khtml-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    }
    .owl-item:first-child>a>.item
    {
    	margin-left: 0 !important;
    }
    .dicount-text
    {
    	position: absolute;
	    top: 0;
	    left: 0;
	    font-size: 1.5em;
	    padding-left: 0.5em;
	    padding-right: 0.5em;
	    padding-top: 0.8em;
    }
    .discount-star
    {
    	width: 90px;
    }
    .box-discount
    {
    	top:-5px;
    }
</style>
<script>
$(document).ready(function() {
	$('.carousel').carousel({
        interval: 3000
    })
	  //New-Products
      var owl = $("#owl-newproducts");
      owl.owlCarousel({
      items : 4, //10 items above 1000px browser width
      itemsDesktop : [1000,2], //5 items between 1000px and 901px
      itemsDesktopSmall : [900,2], // 3 items betweem 900px and 601px
      itemsTablet: [600,1], //2 items between 600 and 0;
      itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
      });

      $(".new-products-next").click(function(){
        owl.trigger('owl.next');
      })
      $(".new-products-prev").click(function(){
        owl.trigger('owl.prev');
      })
      //----End New Products

      //Featured-Products
      var owl1 = $("#owl-featuredproducts");
      owl1.owlCarousel({
      items : 4, //10 items above 1000px browser width
      itemsDesktop : [1000,2], //5 items between 1000px and 901px
      itemsDesktopSmall : [900,2], // 3 items betweem 900px and 601px
      itemsTablet: [600,1], //2 items between 600 and 0;
      itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
      });


      $(".featured-products-next").click(function(){
        owl1.trigger('owl.next');
      })
      $(".featured-products-prev").click(function(){
        owl1.trigger('owl.prev');
      })

      //End Featured-Products

      //discounted products
      var owl2 = $("#owl-discountedproducts");
      owl2.owlCarousel({
      items : 4, //10 items above 1000px browser width
      itemsDesktop : [1000,2], //5 items between 1000px and 901px
      itemsDesktopSmall : [900,2], // 3 items betweem 900px and 601px
      itemsTablet: [600,1], //2 items between 600 and 0;
      itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
      });


      $(".discounted-products-next").click(function(){
        owl2.trigger('owl.next');
      })
      $(".discounted-products-prev").click(function(){
        owl2.trigger('owl.prev');
      })
      //End discounted products

      //popular products
      var owl2 = $("#owl-popularproducts");
      owl2.owlCarousel({
      items : 4, //10 items above 1000px browser width
      itemsDesktop : [1000,2], //5 items between 1000px and 901px
      itemsDesktopSmall : [900,2], // 3 items betweem 900px and 601px
      itemsTablet: [600,1], //2 items between 600 and 0;
      itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
      });


      $(".popular-products-next").click(function(){
        owl2.trigger('owl.next');
      })
      $(".popular-products-prev").click(function(){
        owl2.trigger('owl.prev');
      })
      //End popular products


});


</script>
<script src="<?php echo base_url();?>assets/js/bootstrap-collapse.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap-transition.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap-tab.js"></script>