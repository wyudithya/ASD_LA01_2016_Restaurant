<?php
	if(isset($_GET["orderNumber"]))
		$orderNumber = $_GET["orderNumber"];
?>
<div class="col-md-12">
	<div id="content" align="center">
		<div id="whiteBlock">
			Confirm Payment
		</div>
		<br>
		<div class="col-md-8 col-md-offset-2 no-padding" style="text-align:left">
		<form enctype ="multipart/form-data" action="<?php echo base_url() ?>Order/confirmPayment" method="post">
			<div class="form-group">
	            <div class="row">
	                <div class="col-md-3">
	                    <label for="orderID" style="line-height:2.5">Order to Confirm</label>
	                </div>
	                <div class="col-md-7">
		                <select class="form-control" id="orderID" name="orderID">
		                     <?php 
		                         for($i=0;$i<count($order);$i++) { 
		                            ?>
		                   <option value="<?php echo $order[$i]->orderID;?>">
		                    <?php echo $order[$i]->trackingID;?> - Rp. <?php echo $order[$i]->total+$order[$i]->shippingCost ?> </option>
		                   <?php }?>
		                </select>
	                </div>
	            </div>
	        </div>
	        <div class="form-group">
	            <div class="row">
	                <div class="col-md-3">
	                    <label for="transferDestination" style="line-height:2.5;">Transfer Destination</label>
	                </div>
	                <div class="col-md-7">
		                <select class="form-control" id="transferDestination" name="transferDestination">
		                     <?php 
		                         for($i=0;$i<count($banks);$i++) { 
		                            ?>
		                   <option value="<?php echo $banks[$i]->bankID;?>">
		                    <?php echo $banks[$i]->name;?> - <?php echo $banks[$i]->accountNumber ?> - <?php echo $banks[$i]->holderName; ?> </option>
		                   <?php }?>
		                </select>
	                </div>
	            </div>
	        </div>
	        <div class="form-group">
		        <div class="row">
		            <div class="col-md-3">
		                <label for="bankName" style="line-height:2.5;">Bank Name</label>
		            </div>
		            <div class="col-md-7">
		                <input  type="text" class="form-control" id="bankName" name="bankName" value="" required/>
		            </div>
		        </div>
		    </div>
		    <div class="form-group">
		        <div class="row">
		            <div class="col-md-3">
		                <label for="accountHolder" style="line-height:2.5;">Account Holder Name</label>
		            </div>
		            <div class="col-md-7">
		                <input  type="text" class="form-control" id="accountHolder" name="accountHolder" value="" required/>
		            </div>
		        </div>
		    </div>
		    <div class="form-group">
		        <div class="row">
		            <div class="col-md-3">
		                <label for="accountNumber" style="line-height:2.5;">Account Number</label>
		            </div>
		            <div class="col-md-7">
		                <input  type="number" class="form-control" id="accountNumber" name="accountNumber" value="" required/>
		            </div>
		        </div>
		    </div>
		    <div class="form-group">
		        <div class="row">
		            <div class="col-md-3">
		                <label for="transferDate" style="line-height:2.5;">Transfer Date</label>
		            </div>
		            <div class="col-md-7">
		                <input  type="date" class="form-control" id="transferDate" name="transferDate" value="" required/>
		            </div>
		        </div>
		    </div>
		    <div class="form-group">
		        <div class="row">
		            <div class="col-md-3">
		                <label for="userfile" style="line-height:2.5;">Photo</label>
		            </div>
		            <div class="col-md-7">
		                <input type="file" accept="image/*" class="form-control" id="userfile" name="userfile" value="" required/>
		            </div>
		        </div>
		    </div>
		    <button type="submit" class="btn brown col-md-10">Confirm Payment</button>
		</form>
		</div>
	</div>
</div>
<?php $this->load->view('FrontEnd/footer'); ?> 