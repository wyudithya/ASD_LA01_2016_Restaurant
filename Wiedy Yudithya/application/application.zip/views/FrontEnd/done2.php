<!DOCTYPE html>
<div class="col-md-12">
	<div id="content">
		<div class="col-xs-8 col-xs-offset-2 no-padding" style="margin-top:2em;">
			<div class="box white bottom" style="width:100%;">
				<h2 class="title">Your Order has been Placed</h2>
				<div class="contact" >		
					<div class="col-xs-12">				
						<p class="text-content" style="word-wrap:break-word;"> 
							Pesanan Anda akan datang paling lambat 5 hari kerja. BLABLABLA.<br>
							Mohon untuk menunjukkan invoice kepada petugas saat pengiriman.<br>
							Mohon sediakan uang pas BLABLABLA.<br>
							Terima kasih.
						</p>
					</div>						
						
					<a href="<?php echo base_url('Home'); ?>"><div class="btn brown center col-md-offset-5 col-md-3 col-sm-offset-4 col-sm-3" style="width:10em;margin-top:1.5em;">
						Back to Homepage
					</div></a>
				</div>
			</div>
		</div>
		
	</div>
</div>
	<?php $this->load->view('FrontEnd/footer'); ?>

<script>
    $('.carousel').carousel({
        interval: 3000
    })
</script>