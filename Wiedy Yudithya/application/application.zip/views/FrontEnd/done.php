<!DOCTYPE html>
<div class="col-md-12">
	<div id="content">
		<div class="col-xs-8 col-xs-offset-2 no-padding" style="margin-top:2em;">
			<div class="box white bottom" style="width:100%;">
					<h2 class="title">Your Order has been Placed</h2>
					<div class="contact" >		
						<div class="col-xs-12">				
							<p class="text-content" style="word-wrap:break-word;"> 
								Pemesanan Anda telah terdaftar. Agar kami dapat melanjutkan pemesanan Anda, mohon melakukan pembayaran terlebih dahulu ke rekening kami di :
							</p>
						</div>						
						<div class="hidden-md hidden-lg">
							<div class="col-xs-12">								
								BCA : <b>12312312312 </b> , Atas Nama : <b>54Vape</b><br><br>
							</div>
							<div class="col-xs-12">								
								Mandiri : <b>12312312312 </b> , Atas Nama : <b>54Vape</b><br><br>
							</div>
							<div class="col-md-12">
								Jumlah uang sebesar : <b>Rp1,000,000</b><br><br>
							</div>
						</div>				
						<div class="visible-md visible-lg">
							<div class="col-md-12">
								<div class="col-md-offset-1 col-md-2">
									BCA
								</div>
								<div class="col-md-3">
									: <b>12312312312 </b> 
								</div>
								<div class="col-md-2">
									, Atas Nama 
								</div>
								<div class="col-md-3">
									: <b>54Vape</b> 
								</div>
							</div>
							<div class="col-md-12">
								<div class="col-md-offset-1 col-md-2">
									Mandiri
								</div>
								<div class="col-md-3">
									: <b>12312312312 </b>
								</div>
								<div class="col-md-2">
									, Atas Nama 
								</div>
								<div class="col-md-3">
									: <b>54Vape</b> 
								</div>
							</div>
							<div class="col-md-12">
								<div class="col-md-offset-1 col-md-4">
									Jumlah uang sebesar :
								</div>
								<div class="col-md-5">
									<b>Rp1,000,000</b>
								</div>
							</div>
						</div>				
						<div class="col-xs-12">
							<p class="text-content" style="word-wrap:break-word;">
								Pembayaran dapat dilakukan paling lambat 5 hari kerja (Senin sampai Jumat) setelah pemesanan. Setelah melakukan pembayaran, mohon kirimkan bukti transfer Anda melalui email ke : <b>ISI DISINI</b><br>
								Apabila Anda belum melakukan transfer setelah jangka waktu yang tersedia, kami akan menggugurkan pemesanan Anda.
							</p>
						</div>
						<div class="col-xs-12">
							<p class="text-content" style="word-wrap:break-word;">
								Apabila Anda ingin mendapatkan informasi lebih lanjut, hubungi kami melalui email ke : <b>ISI DISINI</b> atau melalui telepon ke <b>ISI DISINI</b>
							</p>
						</div>
						<div class="col-xs-12">
							<p class="text-content" style="word-wrap:break-word;">
								Terima kasih sudah memilih kami.
							</p>
						</div>
					</div>
					<a href="<?php echo base_url('Home'); ?>"><div class="btn brown center col-md-offset-5 col-md-3 col-sm-offset-4 col-sm-3" style="width:10em;margin-top:1.5em;">
						Back to Homepage
					</div></a>
				</div>
			</div>
		</div>
		
	</div>
	<?php $this->load->view('FrontEnd/footer'); ?>

<script>
    $('.carousel').carousel({
        interval: 3000
    })
</script>